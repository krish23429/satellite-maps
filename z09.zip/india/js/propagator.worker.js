// SGP4 propagation for the whole catalogue, off the main thread.
// Input: orbital elements (OMM fields). Output per step: Earth-fixed (ECEF) position in km,
// ECEF velocity in km/s and a region code (0 elsewhere, 1 within 1,500 km of India, 2 over India).
import { json2satrec, propagate, gstime } from "../../shared/lib/satellite.esm.js";

const OMEGA_E = 7.2921159e-5; // Earth rotation, rad/s
let recs = [], region = null;
// Watch areas: a satellite "has line of sight" to an area when it is at least MIN_EL above the horizon
// from any of the area's reference points. Bit 1 = Kashmir & Ladakh, bit 2 = North East India.
const MIN_EL = 20, SIN_MIN = Math.sin(MIN_EL * Math.PI / 180), RE = 6378.137;
const ZONES = [
  [[34.08, 74.80], [32.73, 74.86], [34.56, 76.13], [34.16, 77.58], [35.10, 77.10], [33.30, 78.70]],   // Srinagar, Jammu, Kargil, Leh, Siachen side, eastern Ladakh
  [[26.14, 91.74], [27.59, 91.86], [27.08, 93.61], [28.07, 95.33], [24.82, 93.94], [25.67, 94.11], [23.73, 92.72], [23.83, 91.29], [25.58, 91.89]] // Guwahati, Tawang, Itanagar, Anini side, Imphal, Kohima, Aizawl, Agartala, Shillong
].map(z => z.map(([la, lo]) => {
  const a = la * Math.PI / 180, b = lo * Math.PI / 180, n = [Math.cos(a) * Math.cos(b), Math.cos(a) * Math.sin(b), Math.sin(a)];
  return { n, p: n.map(c => c * RE) };
}));
function sinEl(site, x, y, z) {
  const dx = x - site.p[0], dy = y - site.p[1], dz = z - site.p[2];
  return (dx * site.n[0] + dy * site.n[1] + dz * site.n[2]) / Math.hypot(dx, dy, dz);
}
function zoneBits(x, y, z) {
  let bits = 0;
  for (let k = 0; k < ZONES.length; k++) for (const site of ZONES[k]) if (sinEl(site, x, y, z) >= SIN_MIN) { bits |= 1 << k; break; }
  return bits;
}
function maxEl(k, x, y, z) {
  let m = -1; for (const site of ZONES[k]) m = Math.max(m, sinEl(site, x, y, z));
  return Math.asin(m) * 180 / Math.PI;
}
function ecef(s, date, g) {
  let pv = null; try { pv = propagate(s, date); } catch (e) { return null; }
  if (!pv || !pv.position || s.error) return null;
  const p = pv.position; if (!isFinite(p.x)) return null;
  const cg = Math.cos(g), sg = Math.sin(g);
  return [p.x * cg + p.y * sg, -p.x * sg + p.y * cg, p.z];
}
// Upcoming passes of the given objects over one watch area, coarse 30 s steps then refined peak.
function passes(idx, zone, t0, hours) {
  const out = [], dt = 30000, steps = Math.ceil(hours * 3600000 / dt);
  const gs = new Float64Array(steps + 1);
  for (let k = 0; k <= steps; k++) gs[k] = gstime(new Date(t0 + k * dt));
  for (const i of idx) {
    const s = recs[i]; if (!s) continue;
    let inPass = false, start = 0, peak = -90, peakT = 0;
    for (let k = 0; k <= steps; k++) {
      const t = t0 + k * dt, p = ecef(s, new Date(t), gs[k]);
      if (!p) { inPass = false; break; }
      const el = maxEl(zone, p[0], p[1], p[2]);
      if (el >= MIN_EL) {
        if (!inPass) { inPass = true; start = t; peak = -90; }
        if (el > peak) { peak = el; peakT = t; }
      } else if (inPass) {
        out.push({ i, start, end: t, peak, peakT }); inPass = false;
        if (out.length > 4000) break;
      }
    }
    if (inPass) out.push({ i, start, end: t0 + steps * dt, peak, peakT, open: true });
  }
  return out;
}

function toSatrec(o) {
  try {
    return json2satrec({
      OBJECT_NAME: "", OBJECT_ID: "", NORAD_CAT_ID: o[0],
      EPOCH: new Date(o[1] * 1000).toISOString(),
      MEAN_MOTION: o[2], ECCENTRICITY: o[3], INCLINATION: o[4], RA_OF_ASC_NODE: o[5],
      ARG_OF_PERICENTER: o[6], MEAN_ANOMALY: o[7], BSTAR: o[8], MEAN_MOTION_DOT: o[9], MEAN_MOTION_DDOT: o[10]
    });
  } catch (e) { return null; }
}

function regionAt(x, y, z) {
  if (!region) return 0;
  const lat = Math.atan2(z, Math.hypot(x, y)) * 180 / Math.PI, lon = Math.atan2(y, x) * 180 / Math.PI;
  const r = Math.floor((lat - region.lat0) / region.step), c = Math.floor((lon - region.lon0) / region.step);
  if (r < 0 || c < 0 || r >= region.h || c >= region.w) return 0;
  return region.cells[r * region.w + c];
}

function step(t) {
  const n = recs.length, pos = new Float32Array(n * 3), vel = new Float32Array(n * 3), reg = new Uint8Array(n), zone = new Uint8Array(n), ok = new Uint8Array(n);
  const date = new Date(t), g = gstime(date), cg = Math.cos(g), sg = Math.sin(g);
  for (let i = 0; i < n; i++) {
    const s = recs[i];
    if (!s) continue;
    let pv = null;
    try { pv = propagate(s, date); } catch (e) { pv = null; }
    if (!pv || !pv.position || !pv.velocity || s.error) continue;
    const p = pv.position, v = pv.velocity;
    if (!isFinite(p.x) || !isFinite(v.x)) continue;
    // TEME/ECI -> ECEF: rotate by Greenwich sidereal time, then remove Earth's rotation from the velocity
    const x = p.x * cg + p.y * sg, y = -p.x * sg + p.y * cg, z = p.z;
    const r = Math.hypot(x, y, z);
    if (r < 6378.137 + 60) continue; // re-entered
    const vx = v.x * cg + v.y * sg + OMEGA_E * y, vy = -v.x * sg + v.y * cg - OMEGA_E * x, vz = v.z;
    pos[3 * i] = x; pos[3 * i + 1] = y; pos[3 * i + 2] = z;
    vel[3 * i] = vx; vel[3 * i + 1] = vy; vel[3 * i + 2] = vz;
    reg[i] = regionAt(x, y, z); zone[i] = zoneBits(x, y, z); ok[i] = 1;
  }
  return { pos, vel, reg, zone, ok };
}

self.onmessage = e => {
  const m = e.data;
  if (m.type === "init") {
    if (m.region) region = m.region;
    recs = m.elements.map(toSatrec);
    self.postMessage({ type: "ready", n: recs.length, bad: recs.filter(r => !r).length });
  } else if (m.type === "passes") {
    const t0 = performance.now();
    self.postMessage({ type: "passes", id: m.id, list: passes(m.idx, m.zone, m.t, m.hours), ms: performance.now() - t0 });
  } else if (m.type === "step") {
    const t0 = performance.now();
    const out = step(m.t);
    self.postMessage({ type: "state", id: m.id, gen: m.gen, t: m.t, ms: performance.now() - t0, ...out },
      [out.pos.buffer, out.vel.buffer, out.reg.buffer, out.zone.buffer, out.ok.buffer]);
  }
};

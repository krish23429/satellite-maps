// World Satellite Watch: every tracked satellite from every owner, which country (or city) it is over right now.
// Orbits: CelesTrak GP elements propagated with SGP4 (satellite.js) in a worker; positions are
// rendered in an Earth-fixed frame, interpolated on the GPU between worker samples (cubic Hermite).
import * as THREE from "three";
import { OrbitControls } from "three/addons/OrbitControls.js";
import { LineSegments2 } from "three/addons/lines/LineSegments2.js";
import { LineSegmentsGeometry } from "three/addons/lines/LineSegmentsGeometry.js";
import { LineMaterial } from "three/addons/lines/LineMaterial.js";
import { json2satrec, propagate, gstime, eciToGeodetic, sunPos } from "../../shared/lib/satellite.esm.js";

const RE = 6378.137, D2R = Math.PI / 180, R2D = 180 / Math.PI;
const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const fmt = n => n.toLocaleString("en-IN");

// ---------------------------------------------------------------- categories and colours
const GROUPS = [
  { id: "IND", name: "India", color: "#ff8a1f", codes: ["IND"] },
  { id: "SL", name: "Starlink (SpaceX)", color: "#9fc3ff", codes: [] },
  { id: "US", name: "United States", color: "#4f8ff7", codes: ["US"] },
  { id: "PRC", name: "China", color: "#f0524f", codes: ["PRC"] },
  { id: "CIS", name: "Russia", color: "#a77bf3", codes: ["CIS"] },
  { id: "EU", name: "Europe", color: "#2fc28b", codes: "FR GER IT UK SPN NETH LUXE FIN NOR GREC POL POR BEL SWTZ DEN BUL ASRA UKR HUN SWED CZCH SVN LTU SVK ROM EST HRV MNE BELA FRIT".split(" ") },
  { id: "JPN", name: "Japan", color: "#ec6aa6", codes: ["JPN"] },
  { id: "INTL", name: "Independent & international", color: "#7fd6e8", codes: "ITSO GLOB ORB IM AB AC ABS ISS NICO RASC SEAL CHBZ STCT TMMC GRSA ESA EUME EUTE SES O3B".split(" ") },
  { id: "OTH", name: "Other countries", color: "#b9c2cf", codes: [] },
  { id: "TBD", name: "Undisclosed", color: "#737d8c", codes: ["TBD", "UNK"] }
];
const GROUP_OF = {}; GROUPS.forEach((g, i) => g.codes.forEach(c => GROUP_OF[c] = i));
const OTH = GROUPS.findIndex(g => g.id === "OTH"), SL = GROUPS.findIndex(g => g.id === "SL");
const TYPES = [
  { id: "comms", name: "Comms" }, { id: "nav", name: "Navigation" }, { id: "imaging", name: "Imaging" },
  { id: "military", name: "Military" }, { id: "weather", name: "Weather" }, { id: "station", name: "Stations" },
  { id: "debris", name: "Debris & rocket bodies" }, { id: "other", name: "Science & other" }
];
const CATS = ["comms", "nav", "imaging", "weather", "station", "science", "other", "debris", "rocket"];
const CAT_TYPE = { comms: "comms", nav: "nav", imaging: "imaging", weather: "weather", station: "station", science: "other", other: "other", debris: "debris", rocket: "debris" };
const CAT_DESC = {
  comms: "Communications", nav: "Navigation / positioning", imaging: "Earth imaging and observation", weather: "Weather and environment",
  station: "Space station", science: "Science and technology", other: "Other or undisclosed purpose",
  debris: "Debris: a fragment left by an earlier mission", rocket: "Spent rocket stage"
};
const ORBITS = ["LEO", "MEO", "GEO", "HEO"];
const ORBIT_DESC = { LEO: "Low Earth orbit", MEO: "Medium Earth orbit", GEO: "Geostationary", HEO: "Highly elliptical" };
const F_MIL = 1, F_ACTIVE = 2, F_EST = 4;
const EST_LABEL = "estimated – amateur tracking";

// ---------------------------------------------------------------- state
const S = {
  n: 0, norad: null, name: [], intl: [], owner: null, group: null, cat: null, flags: null, launch: [], epoch: null,
  orbit: null, op: null, purpose: null, el: [], satrec: [],
  owners: [], operators: [], purposes: [],
  meta: null, geo: null, source: "snapshot", fetchedAt: null
};
const filt = { groups: new Set(GROUPS.map((_, i) => i)), types: new Set(TYPES.map(t => t.id).filter(t => t !== "debris")), orbits: new Set(ORBITS), owner: "", mil: false, active: false };
let visible = new Uint8Array(0), regionMode = 3, selected = -1, minEl = 20, tab = "names";
const sim = { t: Date.now(), speed: 1, paused: false, live: true };
if (params.get("t")) { sim.t = Date.parse(params.get("t")); sim.live = false; }
if (params.get("speed")) { sim.speed = +params.get("speed"); sim.live = false; }

// ---------------------------------------------------------------- renderer and scene
const canvas = $("scene");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
renderer.setSize(innerWidth, innerHeight, false);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(38, innerWidth / innerHeight, 0.005, 4000);
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true; controls.dampingFactor = 0.07; controls.minDistance = 1.06; controls.maxDistance = 40;
controls.zoomSpeed = 0.9; controls.enablePan = false;

const llToVec = (lat, lon, r = 1, out = new THREE.Vector3()) =>
  out.set(r * Math.cos(lat * D2R) * Math.cos(lon * D2R), r * Math.sin(lat * D2R), -r * Math.cos(lat * D2R) * Math.sin(lon * D2R));
const ecfToScene = (x, y, z, out) => out.set(x / RE, z / RE, -y / RE);
const baseDist = () => camera.aspect < 1 ? 4.4 * Math.min(0.8 / Math.max(camera.aspect, 0.4), 1.9) : 4.4;
function viewIndia(dist = 3.2) { camera.position.copy(llToVec(24, 80, dist)); controls.target.set(0, 0, 0); camera.up.set(0, 1, 0); controls.update(); }
const v0 = params.get("view");
if (v0) { const [la, lo, d] = v0.split(",").map(Number); camera.position.copy(llToVec(la, lo, d || baseDist())); } else viewIndia();

// sun direction (Earth-fixed, scene axes)
const sunDir = new THREE.Vector3(1, 0, 0);
function updateSun(t) {
  const jd = t / 86400000 + 2440587.5, r = sunPos(jd).rsun, g = gstime(new Date(t));
  const x = r.x * Math.cos(g) + r.y * Math.sin(g), y = -r.x * Math.sin(g) + r.y * Math.cos(g);
  ecfToScene(x, y, r.z, sunDir).normalize();
}

// ---------------------------------------------------------------- Earth
const texLoader = new THREE.TextureLoader();
// Texture loads retry a few times (a hiccup in the host shouldn't stop the map); after that the Earth just stays plain.
const loadTex = (url, srgb = true, tries = 4) => new Promise((res, rej) => texLoader.load(url + (tries < 4 ? (url.includes("?") ? "&" : "?") + "r=" + tries : ""), t => {
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = renderer.capabilities.getMaxAnisotropy(); t.wrapS = THREE.RepeatWrapping;
  res(t);
}, undefined, () => tries > 1 ? setTimeout(() => loadTex(url, srgb, tries - 1).then(res, rej), 700 * (5 - tries)) : rej(new Error("couldn't load " + url))));
const loadTexSoft = (url, srgb = true) => loadTex(url, srgb).catch(e => { console.warn(e.message); const t = new THREE.DataTexture(new Uint8Array([20, 40, 80, 255]), 1, 1); t.needsUpdate = true; return t; });

const earthU = {
  tDay: { value: null }, tNight: { value: null }, tTopo: { value: null }, tCloud: { value: null },
  uSun: { value: sunDir }, uCloudShift: { value: 0 }, uClouds: { value: 1 }, uTexel: { value: 1 / 4096 },
  tDetail: { value: null }, uDetBox: { value: new THREE.Vector4(0, 0, 0, 0) }, uDetOn: { value: 0 }
};
const earthMat = new THREE.ShaderMaterial({
  uniforms: earthU,
  vertexShader: /* glsl */`
    varying vec2 vUv; varying vec3 vN; varying vec3 vW;
    void main() {
      vUv = uv; vN = normalize(position);
      vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz;
      gl_Position = projectionMatrix * viewMatrix * w;
    }`,
  fragmentShader: /* glsl */`
    uniform sampler2D tDay, tNight, tTopo, tCloud, tDetail;
    uniform vec4 uDetBox; uniform float uDetOn;
    uniform vec3 uSun; uniform float uCloudShift, uClouds, uTexel;
    varying vec2 vUv; varying vec3 vN; varying vec3 vW;
    void main() {
      vec3 N = normalize(vN);
      vec3 east = vec3(N.z, 0.0, -N.x); float el = length(east); east = el > 1e-4 ? east / el : vec3(1.0, 0.0, 0.0);
      vec3 north = cross(N, east);
      vec4 topo = texture2D(tTopo, vUv);
      float h = topo.r, water = topo.g;
      float hx = texture2D(tTopo, vUv + vec2(uTexel, 0.0)).r - texture2D(tTopo, vUv - vec2(uTexel, 0.0)).r;
      float hy = texture2D(tTopo, vUv + vec2(0.0, 2.0 * uTexel)).r - texture2D(tTopo, vUv - vec2(0.0, 2.0 * uTexel)).r;
      vec3 Nb = normalize(N - 2.2 * (hx * east + hy * north));
      vec3 V = normalize(cameraPosition - vW);
      float mu = dot(N, uSun);
      float lit = max(dot(Nb, uSun), 0.0);
      vec3 day = texture2D(tDay, vUv).rgb;
      if (uDetOn > 0.001) {   // NASA 21K detail for the area being looked at
        vec2 d = (vUv - uDetBox.xy) / (uDetBox.zw - uDetBox.xy);
        if (d.x >= 0.0 && d.x <= 1.0 && d.y >= 0.0 && d.y <= 1.0) {
          float edge = smoothstep(0.0, 0.03, min(min(d.x, 1.0 - d.x), min(d.y, 1.0 - d.y)));
          day = mix(day, texture2D(tDetail, d).rgb, edge * uDetOn);
        }
      }
      float cl = texture2D(tCloud, vUv + vec2(uCloudShift, 0.0)).r * uClouds;
      float clShadow = texture2D(tCloud, vUv + vec2(uCloudShift - 0.0015 * uSun.x, 0.001)).r * uClouds;
      // daylight with a warm terminator
      vec3 sunCol = mix(vec3(1.0, 0.45, 0.22), vec3(1.0, 0.97, 0.92), smoothstep(0.0, 0.32, mu));
      vec3 col = day * sunCol * (lit * 2.1 + 0.015) * (1.0 - 0.45 * clShadow);
      // ocean glint
      vec3 H = normalize(V + uSun);
      float nh = max(dot(N, H), 0.0);
      col += sunCol * water * (pow(nh, 90.0) * 1.4 + pow(nh, 14.0) * 0.04) * smoothstep(0.0, 0.12, mu) * (1.0 - cl);
      // city lights on the night side
      vec3 night = texture2D(tNight, vUv).rgb;
      float nightMask = 1.0 - smoothstep(-0.12, 0.06, mu);
      float lum = dot(night, vec3(0.2126, 0.7152, 0.0722));
      vec3 lights = night * smoothstep(0.035, 0.32, lum) * vec3(1.0, 0.8, 0.52);
      col += (lights * 4.0 + day * 0.006) * nightMask * (1.0 - 0.75 * cl);
      // atmospheric haze toward the limb
      float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
      col += vec3(0.28, 0.55, 1.0) * fres * smoothstep(-0.25, 0.45, mu) * 0.85;
      gl_FragColor = vec4(col, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
});
// Detail: the 21,600 x 10,800 NASA Blue Marble cut into 30° tiles (1800 px each). When the camera is close,
// the 2x2 block of tiles under the view is stitched into one texture and blended over the 8K map.
const detail = { key: "", busy: false, cache: new Map(), canvas: document.createElement("canvas"), tex: null, target: 0, lastCheck: 0 };
detail.canvas.width = detail.canvas.height = 3600;
function tileImg(r, c) {
  const k = r + "_" + c;
  if (!detail.cache.has(k)) detail.cache.set(k, new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = `textures/tiles/r${r}c${c}.jpg`; }));
  if (detail.cache.size > 24) detail.cache.delete(detail.cache.keys().next().value);
  return detail.cache.get(k);
}
async function updateDetail(now) {
  if (params.get("detail") === "0") { earthU.uDetOn.value = 0; return; }
  const dist = camera.position.length();
  detail.target = dist < 2.7 ? 1 : 0;
  const u = earthU.uDetOn; u.value += (detail.target - u.value) * 0.08; if (u.value < 0.002) u.value = 0;
  if (!detail.target || detail.busy || now - detail.lastCheck < 400) return;
  detail.lastCheck = now;
  const p = camera.position.clone().normalize(), lat = Math.asin(p.y) * R2D, lon = Math.atan2(-p.z, p.x) * R2D;
  const c0 = Math.min(Math.max(Math.round((lon + 180) / 30 - 1), 0), 10), r0 = Math.min(Math.max(Math.round((90 - lat) / 30 - 1), 0), 4);
  const key = r0 + "_" + c0; if (key === detail.key) return;
  detail.busy = true;
  const ims = await Promise.all([[0, 0], [0, 1], [1, 0], [1, 1]].map(([dr, dc]) => tileImg(r0 + dr, c0 + dc)));
  detail.busy = false;
  if (ims.some(x => !x)) return;
  const g = detail.canvas.getContext("2d");
  ims.forEach((im, k) => g.drawImage(im, (k & 1) * 1800, (k >> 1) * 1800));
  if (!detail.tex) { detail.tex = new THREE.CanvasTexture(detail.canvas); detail.tex.colorSpace = THREE.SRGBColorSpace; detail.tex.anisotropy = renderer.capabilities.getMaxAnisotropy(); earthU.tDetail.value = detail.tex; }
  detail.tex.needsUpdate = true;
  // box in the globe's texture coordinates (u: lon -180..180, v: lat -90..90)
  earthU.uDetBox.value.set(c0 * 30 / 360, (90 - (r0 + 2) * 30 + 90) / 180, (c0 + 2) * 30 / 360, (90 - r0 * 30 + 90) / 180);
  detail.key = key;
}
const earth = new THREE.Mesh(new THREE.SphereGeometry(1, 256, 128), earthMat);
scene.add(earth);

const cloudMat = new THREE.ShaderMaterial({
  uniforms: { tCloud: earthU.tCloud, uSun: earthU.uSun, uCloudShift: earthU.uCloudShift },
  transparent: true, depthWrite: false,
  vertexShader: /* glsl */`
    varying vec2 vUv; varying vec3 vN;
    void main() { vUv = uv; vN = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */`
    uniform sampler2D tCloud; uniform vec3 uSun; uniform float uCloudShift;
    varying vec2 vUv; varying vec3 vN;
    void main() {
      float c = texture2D(tCloud, vUv + vec2(uCloudShift, 0.0)).r;
      float a = smoothstep(0.08, 0.85, c) * 0.92;
      float mu = dot(normalize(vN), uSun);
      vec3 sunCol = mix(vec3(1.0, 0.5, 0.3), vec3(1.0), smoothstep(0.0, 0.3, mu));
      vec3 col = sunCol * (clamp(mu * 1.3 + 0.12, 0.0, 1.0) * 1.7) + vec3(0.004, 0.006, 0.012);
      gl_FragColor = vec4(col, a);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
});
const clouds = new THREE.Mesh(new THREE.SphereGeometry(1.0045, 192, 96), cloudMat);
clouds.visible = false; clouds.renderOrder = 1;
scene.add(clouds);

const atmoMat = new THREE.ShaderMaterial({
  uniforms: { uSun: earthU.uSun },
  side: THREE.BackSide, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  vertexShader: /* glsl */`
    varying vec3 vW;
    void main() { vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
  fragmentShader: /* glsl */`
    uniform vec3 uSun; varying vec3 vW;
    void main() {
      vec3 dir = normalize(vW - cameraPosition);
      vec3 P = cameraPosition - dot(cameraPosition, dir) * dir;   // closest approach of the view ray
      float d = length(P);
      float glow = exp(-max(d - 1.0, 0.0) / 0.011) * smoothstep(1.04, 1.0, d);
      float s = dot(normalize(P), uSun);
      vec3 col = mix(vec3(1.0, 0.42, 0.18), vec3(0.32, 0.6, 1.0), smoothstep(-0.05, 0.35, s));
      gl_FragColor = vec4(col * glow * smoothstep(-0.32, 0.22, s) * 1.6, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
});
scene.add(new THREE.Mesh(new THREE.SphereGeometry(1.04, 128, 64), atmoMat));

// stars and the sun
{
  const n = 9000, p = new Float32Array(n * 3), c = new Float32Array(n * 3);
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < n; i++) {
    const u = rnd() * 2 - 1, th = rnd() * Math.PI * 2, r = Math.sqrt(1 - u * u);
    p.set([r * Math.cos(th) * 1500, u * 1500, r * Math.sin(th) * 1500], i * 3);
    const b = Math.pow(rnd(), 6) * 0.9 + 0.08, tint = rnd();
    c.set([b * (0.85 + 0.15 * tint), b * 0.9, b * (1.05 - 0.2 * tint)], i * 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(p, 3)); g.setAttribute("color", new THREE.BufferAttribute(c, 3));
  scene.add(new THREE.Points(g, new THREE.PointsMaterial({ size: 1.6, sizeAttenuation: false, vertexColors: true, toneMapped: false, depthWrite: false })));
}
const sunSprite = (() => {
  const cv = document.createElement("canvas"); cv.width = cv.height = 128;
  const x = cv.getContext("2d"), gr = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(0.08, "rgba(255,246,225,0.95)"); gr.addColorStop(0.3, "rgba(255,200,130,0.25)"); gr.addColorStop(1, "rgba(255,180,90,0)");
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
  s.scale.setScalar(90); scene.add(s); return s;
})();

// ---------------------------------------------------------------- borders, cities
const overlay = new THREE.Group(); scene.add(overlay);
const lineMats = [];
function fatLines(rings, color, width, r, opacity = 1) {
  const pos = [];
  const a = new THREE.Vector3(), b = new THREE.Vector3();
  for (const ring of rings) {
    for (let k = 0; k + 3 < ring.length; k += 2) {
      llToVec(ring[k + 1], ring[k], r, a); llToVec(ring[k + 3], ring[k + 2], r, b);
      pos.push(a.x, a.y, a.z, b.x, b.y, b.z);
    }
  }
  const g = new LineSegmentsGeometry(); g.setPositions(pos);
  const m = new LineMaterial({ color, linewidth: width, transparent: true, opacity, depthWrite: false, toneMapped: false });
  m.resolution.set(innerWidth, innerHeight); lineMats.push(m);
  const l = new LineSegments2(g, m); l.renderOrder = 2; return l;
}
const cityPts = [];
function buildGeo(geo) {
  // only the faint world borders are always on; borders, states and cities come with the selected country
  overlay.add(fatLines(geo.world, 0x9db4dc, 0.8, 1.0012, 0.32));
  const seen = [];
  for (const c of seen) cityPts.push({ ...c, v: llToVec(c.lat, c.lon, 1.002) });
}

// ---------------------------------------------------------------- satellites (points)
const satU = { uS: { value: 0 }, uDT: { value: 1 }, uPx: { value: renderer.getPixelRatio() }, uTime: { value: 0 } };
const satMat = new THREE.ShaderMaterial({
  uniforms: satU, transparent: true, depthWrite: false, toneMapped: false,
  vertexShader: /* glsl */`
    attribute vec3 p0; attribute vec3 v0; attribute vec3 p1; attribute vec3 v1;
    attribute vec3 aColor; attribute float aSize; attribute float aFx;
    uniform float uS, uDT, uPx, uTime;
    varying vec3 vColor; varying float vFx;
    void main() {
      float s = clamp(uS, 0.0, 1.35), s2 = s * s, s3 = s2 * s;
      vec3 p = (2.0 * s3 - 3.0 * s2 + 1.0) * p0 + (s3 - 2.0 * s2 + s) * uDT * v0 + (-2.0 * s3 + 3.0 * s2) * p1 + (s3 - s2) * uDT * v1;
      vec3 w = vec3(p.x, p.z, -p.y) / 6378.137;
      vec4 mv = modelViewMatrix * vec4(w, 1.0);
      gl_Position = projectionMatrix * mv;
      float size = aSize * uPx * clamp(4.2 / -mv.z, 0.8, 1.9);
      gl_PointSize = aSize > 0.0 ? max(size, 1.0) : 0.0;
      if (aSize <= 0.0) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      vColor = aColor; vFx = aFx;
    }`,
  fragmentShader: /* glsl */`
    uniform float uTime;
    varying vec3 vColor; varying float vFx;
    void main() {
      vec2 c = gl_PointCoord * 2.0 - 1.0; float d = length(c);
      float over = mod(vFx, 2.0), est = mod(floor(vFx / 2.0), 2.0), sel = mod(floor(vFx / 4.0), 2.0);
      float ringed = max(max(over, est), sel);
      float rc = ringed > 0.5 ? 0.4 : 1.0;
      float core = smoothstep(rc, rc * 0.35, d);
      vec3 col = vColor * (1.15 + 0.6 * smoothstep(rc * 0.5, 0.0, d)) + vec3(0.18) * smoothstep(rc * 0.4, 0.0, d);
      float a = core;
      if (ringed > 0.5) {
        float rr = est > 0.5 ? 0.72 + 0.1 * sin(uTime * 4.0) : 0.78;
        float ring = smoothstep(0.13, 0.02, abs(d - rr));
        vec3 rcol = sel > 0.5 ? vec3(1.0) : (est > 0.5 ? vec3(1.0, 0.24, 0.95) : vec3(1.0, 0.62, 0.2));
        col = mix(col, rcol * 1.2, ring * (1.0 - core));
        a = max(a, ring * 0.95);
      }
      if (a < 0.03) discard;
      gl_FragColor = vec4(col, a);
      #include <colorspace_fragment>
    }`
});
let satGeo = null, satPoints = null;
const attr = {};
function buildPoints() {
  if (satPoints) { scene.remove(satPoints); satGeo.dispose(); }
  const n = S.n;
  satGeo = new THREE.BufferGeometry();
  for (const k of ["p0", "v0", "p1", "v1", "aColor"]) { attr[k] = new THREE.BufferAttribute(new Float32Array(n * 3), 3); attr[k].setUsage(THREE.DynamicDrawUsage); satGeo.setAttribute(k, attr[k]); }
  for (const k of ["aSize", "aFx"]) { attr[k] = new THREE.BufferAttribute(new Float32Array(n), 1); attr[k].setUsage(THREE.DynamicDrawUsage); satGeo.setAttribute(k, attr[k]); }
  satGeo.setAttribute("position", attr.p0); // three wants a "position"; the shader ignores it
  satGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
  const col = new THREE.Color();
  for (let i = 0; i < n; i++) {
    col.set(GROUPS[S.group[i]].color);
    const t = S.cat[i]; const dim = t === 7 || t === 8 ? 0.55 : 1;
    attr.aColor.setXYZ(i, col.r * dim, col.g * dim, col.b * dim);
  }
  satPoints = new THREE.Points(satGeo, satMat); satPoints.frustumCulled = false; satPoints.renderOrder = 5;
  scene.add(satPoints);
}

// ---------------------------------------------------------------- catalogue ingest
function ingest(cat) {
  const objs = cat.objects, n = objs.length;
  S.meta = cat; S.n = n; S.owners = cat.owners; S.operators = cat.operators; S.purposes = cat.purposes;
  S.norad = new Int32Array(n); S.owner = new Uint16Array(n); S.group = new Uint8Array(n); S.cat = new Uint8Array(n);
  S.flags = new Uint8Array(n); S.epoch = new Float64Array(n); S.orbit = new Uint8Array(n); S.op = new Uint16Array(n); S.purpose = new Uint16Array(n);
  S.name = new Array(n); S.intl = new Array(n); S.launch = new Array(n); S.el = new Array(n); S.satrec = new Array(n);
  for (let i = 0; i < n; i++) {
    const o = objs[i];
    S.norad[i] = o[0]; S.name[i] = o[1]; S.intl[i] = o[2]; S.owner[i] = o[3];
    const code = cat.owners[o[3]][0]; S.group[i] = o[1].startsWith("STARLINK") ? SL : (GROUP_OF[code] ?? OTH);
    S.cat[i] = Math.max(0, CATS.indexOf(o[4])); S.flags[i] = o[5]; S.launch[i] = o[6]; S.epoch[i] = o[7];
    S.el[i] = o.slice(8, 17); S.op[i] = o[17]; S.purpose[i] = o[18]; S.orbit[i] = Math.max(0, ORBITS.indexOf(o[19]));
  }
  visible = new Uint8Array(n);
}
function satrecOf(i) {
  if (!S.satrec[i]) {
    const e = S.el[i];
    S.satrec[i] = json2satrec({ OBJECT_NAME: S.name[i], OBJECT_ID: S.intl[i], NORAD_CAT_ID: S.norad[i], EPOCH: new Date(S.epoch[i] * 1000).toISOString(),
      MEAN_MOTION: e[0], ECCENTRICITY: e[1], INCLINATION: e[2], RA_OF_ASC_NODE: e[3], ARG_OF_PERICENTER: e[4], MEAN_ANOMALY: e[5], BSTAR: e[6], MEAN_MOTION_DOT: e[7], MEAN_MOTION_DDOT: e[8] });
  }
  return S.satrec[i];
}

// ---------------------------------------------------------------- worker pipeline
let worker = null, gen = 0, busy = false, reqId = 0, workerMs = 40;
let states = [];            // sorted samples {t, pos, vel, reg, ok}
let pair = [null, null];    // the two samples currently uploaded to the GPU
function startWorker() {
  if (worker) worker.terminate();
  worker = new Worker(new URL("./propagator.worker.js", import.meta.url), { type: "module" });
  const g = S.grid, cells = g.cells;
  const elements = new Array(S.n);
  for (let i = 0; i < S.n; i++) elements[i] = [S.norad[i], S.epoch[i], ...S.el[i]];
  busy = true; gen++; states = []; pair = [null, null];
  return new Promise(res => {
    worker.onmessage = e => {
      const m = e.data;
      if (m.type === "ready") { busy = false; res(m); }
      else if (m.type === "state") onState(m);
      else if (m.type === "passes") onPasses(m);
    };
    worker.postMessage({ type: "init", elements, region: { ...g, cells }, zones: AREAS[regionMode] && AREAS[regionMode].city ? [[[AREAS[regionMode].ll[0], AREAS[regionMode].ll[1]]]] : [], minEl });
  });
}
const stepSim = () => Math.min(Math.max(Math.abs(sim.speed) * 600, 400), 600000); // ms of sim time between samples
function request(t) { busy = true; worker.postMessage({ type: "step", t, id: ++reqId, gen }); }
function onState(m) {
  busy = false;
  workerMs = workerMs * 0.8 + m.ms * 0.2;
  if (m.gen !== gen) return;
  states.push({ t: m.t, pos: m.pos, vel: m.vel, reg: m.reg, zone: m.zone, ok: m.ok });
  states.sort((a, b) => a.t - b.t);
  if (states.length > 4) states.shift();
}
function resync() { gen++; states = []; }
function pumpWorker() {
  if (!worker || busy) return;
  const last = states[states.length - 1];
  if (!last) { request(sim.t); return; }
  if (states.length < 4 && last.t < sim.t + 2 * stepSim()) request(Math.max(last.t, sim.t - stepSim()) + stepSim());
}
function upload(a, b) {
  attr.p0.array.set(a.pos); attr.v0.array.set(a.vel); attr.p1.array.set(b.pos); attr.v1.array.set(b.vel);
  for (const k of ["p0", "v0", "p1", "v1"]) attr[k].needsUpdate = true;
  pair = [a, b];
  if (AREAS[regionMode] && AREAS[regionMode].poly) computePoly(b);
  refreshSizes();
  updateCounter();
  pickLabelCandidates();
}
function advance() {
  while (states.length >= 3 && states[1].t <= sim.t) states.shift();
  if (states.length === 0) return;
  let a = states[0], b = states[1] || states[0];
  if (states.length >= 2 && sim.t < a.t) b = a; // rewound before the buffer
  if (a !== pair[0] || b !== pair[1]) upload(a, b);
  const dt = (b.t - a.t) / 1000;
  satU.uDT.value = dt;
  satU.uS.value = dt > 0 ? (sim.t - a.t) / (b.t - a.t) : 0;
}
// Watch areas. Mode 2 = India (ground point inside India's borders); modes 3+ = line of sight to zone (mode - 3).
// Countries come from data/world.json: a 0.25° grid of country codes (run-length encoded) and outlines.
// Code 1 is India with India's official borders; the rest follow Natural Earth (via world-atlas).
let ZONE_DEFS = [], AREAS = {}, WORLD = null, AREA_KM2 = null, codeByName = {};
const SOUTH_ASIA = ["India", "Pakistan", "Bangladesh", "Sri Lanka", "Nepal", "Bhutan", "Maldives", "Afghanistan"];
const CONT_ORDER = ["Asia", "Europe", "Africa", "North America", "South America", "Oceania", "Antarctica", "Other"], CONT_LABEL = { Other: "Disputed &amp; other" };
function decodeGrid(g) {
  const raw = Uint8Array.from(atob(g.rle), c => c.charCodeAt(0)), pairs = new Uint16Array(raw.buffer), cells = new Uint16Array(g.w * g.h);
  let q = 0; for (let k = 0; k < pairs.length; k += 2) { cells.fill(pairs[k], q, q + pairs[k + 1]); q += pairs[k + 1]; }
  return { lat0: g.lat0, lon0: g.lon0, step: g.step, w: g.w, h: g.h, cells };
}
function buildAreas(world) {
  WORLD = world;
  world.countries.forEach((c, k) => codeByName[c.name] = k + 1);
  const C = n => world.countries[codeByName[n] - 1], one = n => ({ name: n === "United States of America" ? "United States" : n, short: n, codes: [codeByName[n]], ll: C(n).ll, d: C(n).d, cont: C(n).cont });
  const sa = SOUTH_ASIA.map(n => codeByName[n]);
  ZONE_DEFS = [
    { name: "South Asia", short: "South Asia", sub: "India · Pakistan · Bangladesh · Sri Lanka · Nepal · Bhutan · Maldives · Afghanistan", codes: sa, ll: [24, 78], d: 3.0, group: "top" },
    ...[...SOUTH_ASIA, "Myanmar", "China"].map(n => ({ ...one(n), group: "top", sub: undefined })),
    { name: "South Asia + Myanmar + China", short: "Region", codes: [...sa, codeByName.Myanmar, codeByName.China], ll: [28, 88], d: 3.5, group: "top" },
    ...world.countries.map((c, k) => k + 1).filter(code => !sa.includes(code) && code !== codeByName.Myanmar && code !== codeByName.China)
      .sort((a, b) => world.countries[a - 1].name.localeCompare(world.countries[b - 1].name)).map(code => ({ ...one(world.countries[code - 1].name), group: world.countries[code - 1].cont }))
  ];
  AREAS = {};
  ZONE_DEFS.forEach((z, k) => { const mask = new Uint8Array(world.countries.length + 2); z.codes.forEach(c => mask[c] = 1); AREAS[3 + k] = { ...z, mask, zone: k }; });
  AREA_KM2 = ZONE_DEFS.map(z => z.codes.reduce((t, c) => t + world.countries[c - 1].km2, 0));
  const row = (z, k) => `<button data-mode="${3 + k}" data-name="${esc(z.name.toLowerCase())}" class="${z.codes.length > 1 ? "star" : "sub-area"}"><span class="an">${esc(z.name)}${z.sub ? `<small>${z.sub}</small>` : ""}</span><span class="ac">–</span><span class="am">–</span></button>`;
  let html = `<div class="cgroup-head">South Asia &amp; neighbours</div>`;
  ZONE_DEFS.forEach((z, k) => { if (z.group === "top") html += row(z, k); });
  html += `<div class="cfind"><input id="countrySearch" type="search" placeholder="Find a country or any of 135,000 cities" autocomplete="off"><div id="placeResults" hidden></div><label class="check"><input type="checkbox" id="onlyOver" checked> Only countries with satellites overhead</label></div>`;
  for (const cont of CONT_ORDER) {
    const ks = ZONE_DEFS.map((z, k) => k).filter(k => ZONE_DEFS[k].group === cont); if (!ks.length) continue;
    html += `<div class="cgroup" data-cont="${cont}"><div class="cgroup-head">${CONT_LABEL[cont] || cont} <span class="cgc"></span></div>` + ks.map(k => row(ZONE_DEFS[k], k)).join("") + `</div>`;
  }
  $("regionMode").innerHTML = html;
  { // place search goes to the top bar, satellite search into the panel
    const hdr = document.querySelector("header .search"), cf = document.querySelector(".cfind");
    const satIn = $("search"), satRes = $("searchResults"), plIn = $("countrySearch"), plRes = $("placeResults");
    hdr.prepend(plRes); hdr.prepend(plIn); cf.prepend(satRes); cf.prepend(satIn);
    plIn.placeholder = "Search a country, city, state or region (e.g. Siberia, Karur)";
    satIn.placeholder = "Find a satellite (name or NORAD id)";
  }
  { const bar = document.createElement("div"); bar.id = "pickedBar";
    bar.innerHTML = `<div><span class="pk-name"></span><span class="pk-kind sub"></span></div><button type="button" class="pk-back">All countries</button>`;
    const panelBody = document.querySelector("#india .panel-body"); panelBody.insertBefore(bar, panelBody.firstChild);
    bar.querySelector(".pk-back").onclick = () => { showPicked(false); $("countrySearch").value = ""; setArea(3, true); };
  }
  $("countrySearch").oninput = () => { filterRows(); placeSearch(); };
  $("countrySearch").onkeydown = e => { if (e.key === "Enter") { const b = $("placeResults").querySelector("button"); if (b) b.click(); } else if (e.key === "Escape") { $("placeResults").hidden = true; searchMode(false); } };
  $("placeResults").onclick = e => {
    const b = e.target.closest("button"); if (!b) return;
    $("placeResults").hidden = true; searchMode(false);
    const after = () => showPicked(true);
    if (b.dataset.city != null) { setCity(S.cities[+b.dataset.city]); after(); }
    else if (b.dataset.place != null) setPlace(+b.dataset.place).then(after);
    else { setArea(+b.dataset.mode, true); after(); }
  };
  $("onlyOver").onchange = () => { filterRows(); };
}
let lastCounts = null;
const norm = t => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
function placeSearch() {
  const box = $("placeResults"), q = norm($("countrySearch").value.trim());
  if (q.length < 2 || !S.cities) { box.hidden = true; searchMode(false); return; }
  const cs = [], ci = [];
  ZONE_DEFS.forEach((z, k) => { const n = norm(z.name); if (n.includes(q)) cs.push([n.startsWith(q) ? 0 : 1, k]); });
  for (let k = 0; k < S.cities.length && ci.length < 60; k++) { const n = S.cityNorm[k]; if (n.includes(q)) ci.push([n.startsWith(q) ? 0 : 1, k]); }
  const pl = []; if (S.places) for (let k = 0; k < S.places.length && pl.length < 30; k++) { const n = S.placeNorm[k]; if (n.includes(q)) pl.push([n.startsWith(q) ? 0 : 1, k]); }
  pl.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  cs.sort((a, b) => a[0] - b[0]); ci.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  box.innerHTML = cs.slice(0, 5).map(([, k]) => `<button data-mode="${3 + k}"><b>${esc(ZONE_DEFS[k].name)}</b><span class="sub">${ZONE_DEFS[k].codes.length > 1 ? "group" : "country"}</span></button>`).join("") +
    pl.slice(0, 6).map(([, k]) => { const p = S.places[k]; return `<button data-place="${k}">${esc(p[0])}<span class="sub">${esc(p[1])}${p[5] && WORLD.countries[p[5] - 1] ? " · " + esc(WORLD.countries[p[5] - 1].name) : ""}</span></button>`; }).join("") +
    ci.slice(0, 10).map(([, k]) => { const c = S.cities[k]; return `<button data-city="${k}">${esc(c[0])}<span class="sub">${esc(WORLD.countries[c[1] - 1].name)}${c[5] ? " · capital" : ""}${c[4] ? " · " + (c[4] >= 1e6 ? (c[4] / 1e6).toFixed(1) + "M" : Math.round(c[4] / 1e3) + "k") : ""}</span></button>`; }).join("");
  box.hidden = !box.innerHTML;
  searchMode(!box.hidden);
}
function searchMode(on) { document.body.classList.toggle("searching", on); }
// After picking something from the top search, the panel shows only that pick (the full list is one tap away).
function showPicked(on) {
  document.body.classList.toggle("picked", on);
  const bar = $("pickedBar");
  if (on && bar) { const a = AREAS[regionMode]; bar.querySelector(".pk-name").textContent = a ? a.name + (a.countryName ? ", " + a.countryName : "") : ""; bar.querySelector(".pk-kind").textContent = a ? (a.kind || (a.city ? "city / place" : a.codes.length > 1 ? "group" : "country")) : ""; }
}
document.addEventListener("pointerdown", e => {
  const box = $("placeResults"); if (!box || box.hidden) return;
  if (!e.target.closest("header .search")) { box.hidden = true; searchMode(false); }
});
// A city works like a watch area of its own: satellites at least minEl° above its horizon, with next passes.
const CITY = 1000;
function setCity(c, d = 1.5) {
  const country = c[1] ? WORLD.countries[c[1] - 1] : null;
  AREAS[CITY] = { name: country ? `${c[0]}, ${country.name}` : c[0], short: c[0], codes: c[1] ? [c[1]] : [], mask: new Uint8Array(1), ll: [c[2], c[3]], d, city: c, zone: 0 };
  if (worker) worker.postMessage({ type: "zones", zones: [[[c[2], c[3]]]] });
  resync(); passState.list = []; passState.dirty = true;
  setArea(CITY, true);
}
function filterRows() {
  const q = "", only = $("onlyOver")?.checked;   // the top search shows its own results; the list stays whole
  document.querySelectorAll("#regionMode .cgroup").forEach(g => {
    let shown = 0, over = 0;
    g.querySelectorAll("button").forEach(b => {
      const k = +b.dataset.mode - 3, n = lastCounts ? lastCounts[k] : 1;
      if (n > 0) over++;
      const ok = (!q || b.dataset.name.includes(q)) && (!only || n > 0 || +b.dataset.mode === regionMode || q);
      b.hidden = !ok; if (ok) shown++;
    });
    g.hidden = !shown; g.querySelector(".cgc").textContent = `${over} with satellites overhead`;
  });
}
// The selected country (or group) gets the full treatment India used to have: golden border, state lines,
// state names and its biggest cities. Details load per continent from data/detail/.
let selStateLabels = [];
const detailCache = {};
const loadDetail = cont => detailCache[cont] ||= getJson("data/detail/" + cont.toLowerCase().replace(/ /g, "-") + ".json").catch(() => ({}));
let hiGroup = null, hiToken = 0;
async function highlightArea() {
  const token = ++hiToken, a = AREAS[regionMode]; if (!a || !WORLD) return;
  const conts = [...new Set(a.codes.map(c => WORLD.countries[c - 1].cont))];
  const bundles = await Promise.all(conts.map(loadDetail));
  if (token !== hiToken) return;   // another country was picked meanwhile
  const det = Object.assign({}, ...bundles);
  if (hiGroup) { overlay.remove(hiGroup); hiGroup.traverse(o => o.geometry && o.geometry.dispose()); hiGroup = null; }
  const border = [], states = [];
  cityPts.length = 0; selStateLabels = [];
  for (const c of a.codes) {
    const d = det[c];
    border.push(...(c === 1 ? S.geo.india : d && d.b && d.b.length ? d.b : (WORLD.countries[c - 1].rings || [])));
    if (!d) continue;
    states.push(...d.s);
    const named = new Set(); [...d.l].sort((p, q) => (p[3] || 0) - (q[3] || 0)).forEach(x => { if (named.has(x[0])) return; named.add(x[0]); selStateLabels.push({ n: x[0], lon: x[1], lat: x[2] }); });
  }
  if (a.city) cityPts.push({ n: a.city[0], lat: a.city[2], lon: a.city[3], rank: 0, site: 1, v: llToVec(a.city[2], a.city[3], 1.002) });
  if (a.poly) {
    border.push(...a.poly);
    const [x0, y0, x1, y1] = a.bb; let rank = 0;
    for (const x of S.cities || []) { if (x[2] < y0 || x[2] > y1 || x[3] < x0 || x[3] > x1 || !pipRings(a.poly, x[3], x[2])) continue;
      cityPts.push({ n: x[0], lat: x[2], lon: x[3], pop: x[4], rank: rank++, v: llToVec(x[2], x[3], 1.002) }); }
  }
  const rankBy = {}, want = new Set(a.codes);
  for (const x of S.cities || []) { if (!want.has(x[1])) continue; const rank = rankBy[x[1]] = (rankBy[x[1]] ?? -1) + 1; if (a.city && x === a.city) continue;
    cityPts.push({ n: x[0], lat: x[2], lon: x[3], pop: x[4], cap: x[5], rank: a.city ? rank + 1 : rank, v: llToVec(x[2], x[3], 1.002) }); }
  cityPts.sort((p, q) => (q.site || 0) - (p.site || 0) || p.rank - q.rank);
  hiGroup = new THREE.Group();
  if (states.length) hiGroup.add(fatLines(states, 0xffd3a0, 0.9, 1.0013, 0.55));
  if (border.length) hiGroup.add(fatLines(border, 0xffa23a, 2.2, 1.0015, 1));
  overlay.add(hiGroup);
}
const areaFoot = () => AREAS[regionMode] && AREAS[regionMode].poly ? `Counted when the point straight below the satellite is inside ${AREAS[regionMode].name} (${AREAS[regionMode].kind}; outline from Natural Earth).` : AREAS[regionMode] && AREAS[regionMode].city ? `In the sky = at least ${minEl}° above the horizon as seen from ${AREAS[regionMode].name}.` :
  `Counted when the point straight below the satellite is inside ${AREAS[regionMode] ? AREAS[regionMode].name : "the area"}. India uses India's official borders; other borders from Natural Earth.`;
const inArea = (b, i) => { const a = AREAS[regionMode]; return !a ? false : a.poly ? (b === polyIn.b && polyIn.v[i] === 1) : a.city ? !!(b.zone && (b.zone[i] & 1)) : a.mask[b.reg[i]] === 1; };
// Regions, seas and states with an outline: a satellite counts when its ground point is inside the outline.
const polyIn = { b: null, v: new Uint8Array(0) };
function pipRings(rings, x, y) {
  let c = false;
  for (const r of rings) for (let i = 0, j = r.length - 2; i < r.length; j = i, i += 2) {
    const yi = r[i + 1], yj = r[j + 1];
    if ((yi > y) !== (yj > y) && x < (r[j] - r[i]) * (y - yi) / (yj - yi) + r[i]) c = !c;
  }
  return c;
}
function computePoly(b) {
  const a = AREAS[regionMode]; if (!a || !a.poly || !b) return;
  if (polyIn.v.length !== S.n) polyIn.v = new Uint8Array(S.n);
  const v = polyIn.v, [x0, y0, x1, y1] = a.bb; v.fill(0);
  for (let i = 0; i < S.n; i++) {
    if (!b.ok[i]) continue;
    const k = 3 * i, x = b.pos[k], y = b.pos[k + 1], z = b.pos[k + 2];
    const lat = Math.atan2(z, Math.hypot(x, y)) * R2D; if (lat < y0 || lat > y1) continue;
    const lon = Math.atan2(y, x) * R2D; if (lon < x0 || lon > x1) continue;
    if (pipRings(a.poly, lon, lat)) v[i] = 1;
  }
  polyIn.b = b;
}
let placeShapes = null;
async function setPlace(k) {
  const p = S.places[k];
  if (!p[6]) { setCity([p[0], p[5], p[2], p[3], 0, 0], /island|state/.test(p[1]) ? 1.8 : 2.3); return; }
  placeShapes ||= getJson("data/place-shapes.json").catch(() => ({}));
  const shapes = await placeShapes, rings = shapes[k];
  if (!rings) { setCity([p[0], p[5], p[2], p[3], 0, 0], 2.0); return; }
  const bb = p[6], span = Math.max(bb[3] - bb[1], (bb[2] - bb[0]) * Math.cos((bb[1] + bb[3]) / 2 * D2R));
  const country = p[5] ? WORLD.countries[p[5] - 1] : null;
  AREAS[CITY] = { name: p[0], short: p[0], kind: p[1], codes: [], mask: new Uint8Array(1), ll: [p[2], p[3]], d: Math.min(Math.max(1.35 + span / 28, 1.5), 3.6),
    poly: rings, bb, city: null, place: p, countryName: country ? country.name : "" };
  polyIn.b = null;
  setArea(CITY, true);
}
// CPU copy of the GPU interpolation, for labels and picking
const _p = new THREE.Vector3();
function posAt(i, out = _p) {
  const [a, b] = pair; if (!a) return null;
  if (!a.ok[i] || !b.ok[i]) return null;
  const s = Math.min(Math.max(satU.uS.value, 0), 1.35), s2 = s * s, s3 = s2 * s, dt = satU.uDT.value;
  const h00 = 2 * s3 - 3 * s2 + 1, h10 = (s3 - 2 * s2 + s) * dt, h01 = -2 * s3 + 3 * s2, h11 = (s3 - s2) * dt, k = 3 * i;
  const x = h00 * a.pos[k] + h10 * a.vel[k] + h01 * b.pos[k] + h11 * b.vel[k];
  const y = h00 * a.pos[k + 1] + h10 * a.vel[k + 1] + h01 * b.pos[k + 1] + h11 * b.vel[k + 1];
  const z = h00 * a.pos[k + 2] + h10 * a.vel[k + 2] + h01 * b.pos[k + 2] + h11 * b.vel[k + 2];
  return ecfToScene(x, y, z, out);
}

// ---------------------------------------------------------------- filters
function passes(i) {
  if (filt.owner) { if (S.owners[S.owner[i]][0] !== filt.owner) return false; }
  else if (!filt.groups.has(S.group[i])) return false;
  if (!filt.orbits.has(ORBITS[S.orbit[i]])) return false;
  const f = S.flags[i];
  if (filt.active && !(f & F_ACTIVE)) return false;
  if (filt.mil) return !!(f & F_MIL);
  const t = CAT_TYPE[CATS[S.cat[i]]], milOn = filt.types.has("military");
  if (f & F_MIL) return milOn;   // military objects follow the Military chip, whatever their purpose
  return filt.types.has(t);
}
function applyFilters() {
  let shown = 0;
  for (let i = 0; i < S.n; i++) { visible[i] = passes(i) ? 1 : 0; shown += visible[i]; }
  $("shownCount").textContent = fmt(shown);
  refreshSizes(); updateCounter(); pickLabelCandidates(); renderChips(); passState.dirty = true;
}
function refreshSizes() {
  if (!attr.aSize) return;
  const b = pair[1], size = attr.aSize.array, fx = attr.aFx.array;
  for (let i = 0; i < S.n; i++) {
    if (!visible[i] || (b && !b.ok[i])) { size[i] = 0; fx[i] = 0; continue; }
    const c = S.cat[i], f = S.flags[i];
    let s = c === 7 ? 1.7 : c === 8 ? 2.1 : 2.7, e = 0;
    if (S.orbit[i] !== 0 && c < 7) s *= 1.45;   // MEO / GEO / HEO: keep them visible from far out
    if (S.group[i] === 0) s += 1.1;
    if (filt.mil) s += 0.8;
    if (b && c < 7 && inArea(b, i)) { e += 1; s = s * 1.6 + 3; }
    if ((f & F_EST) && filt.mil) { e |= 2; s = Math.max(s, 9); }
    if (i === selected) { e |= 4; s = Math.max(s * 1.4, 12); }
    if (modelOn[i] && !e) s *= 0.35;   // a 3D model is drawn here; keep only a faint glint
    size[i] = s; fx[i] = e;
  }
  attr.aSize.needsUpdate = attr.aFx.needsUpdate = true;
}

// ---------------------------------------------------------------- India counter
function updateCounter() {
  const b = pair[1]; if (!b) return;
  const counts = new Map(); let total = 0;
  const byPurpose = true;
  if (!WORLD) return;
  const byGroup = new Array(GROUPS.length).fill(0);
  const byCode = new Uint32Array(WORLD.countries.length + 2), zt = new Array(ZONE_DEFS.length).fill(0), inView = [];
  for (let i = 0; i < S.n; i++) {
    if (!visible[i] || !b.ok[i]) continue;
    byCode[b.reg[i]]++;
    if (!inArea(b, i)) continue;
    inView.push(i);
    total++; const k = purposeKey(i); counts.set(k, (counts.get(k) || 0) + 1); byGroup[S.group[i]]++;
  }
  $("indiaTotal").textContent = fmt(total);
  $("areaTitle").textContent = AREAS[regionMode].city ? `Satellites in the sky over ${AREAS[regionMode].name} now` : `Satellites over ${AREAS[regionMode].name}${AREAS[regionMode].countryName ? ", " + AREAS[regionMode].countryName : ""} now`;
  $("areaFoot").textContent = areaFoot() + " Counts follow the filters.";
  for (let k = 0; k < ZONE_DEFS.length; k++) zt[k] = ZONE_DEFS[k].codes.reduce((t, c) => t + byCode[c], 0);
  const rowsEl = $("regionMode").querySelectorAll("button[data-mode]");
  for (const row of rowsEl) {
    const k = +row.dataset.mode - 3;
    row.querySelector(".ac").textContent = fmt(zt[k]);
    row.querySelector(".am").textContent = AREA_KM2[k] ? (zt[k] / AREA_KM2[k] * 1e5).toFixed(1) : "–";
  }
  const changed = !lastCounts || zt.some((v, k) => (v > 0) !== (lastCounts[k] > 0));
  lastCounts = zt; if (changed) filterRows();
  sightList = inView;
  renderRollcall(inView);
  const rows = [...counts.entries()].sort((x, y) => y[1] - x[1]);
  const top = rows.slice(0, 9), rest = rows.slice(9).reduce((a, r) => a + r[1], 0);
  const max = top.length ? top[0][1] : 1;
  const html = top.map(([o, v]) => {
    let color, name;
    if (byPurpose) { color = PURPOSE[o].color; name = PURPOSE[o].name; }
    else { const g = GROUPS[GROUP_OF[S.owners[o][0]] ?? OTH]; color = g.color; name = S.owners[o][1]; }
    const g = { color };
    return `<div class="bar"><span class="name"><span class="sw" style="background:${g.color}"></span>${esc(name)}</span><span class="v">${fmt(v)}</span><span class="track"><span class="fill" style="display:block;width:${(v / max * 100).toFixed(1)}%;background:${g.color}"></span></span></div>`;
  }).join("") + (rest ? `<div class="bar"><span class="name">Others</span><span class="v">${fmt(rest)}</span></div>` : "") ||
    `<div class="sub">Nothing matching the filters is over the area right now.</div>`;
  const gmax = Math.max(1, ...byGroup);
  const ghtml = `<div class="bd-head">By owner</div>` + GROUPS.map((g, k) => [g, byGroup[k]]).filter(x => x[1]).sort((x, y) => y[1] - x[1]).map(([g, v]) =>
    `<div class="bar"><span class="name"><span class="sw" style="background:${g.color}"></span>${esc(g.name)}</span><span class="v">${fmt(v)}</span><span class="track"><span class="fill" style="display:block;width:${(v / gmax * 100).toFixed(1)}%;background:${g.color}"></span></span></div>`).join("");
  const full = ghtml + `<div class="bd-head">By type</div>` + html;
  const el = $("indiaBars"); if (el._h !== full) { el.innerHTML = full; el._h = full; }
}
const PURPOSE = {
  milest: { name: "Military, amateur-tracked (secret)", color: "#ff3fd8" },
  mil: { name: "Military & reconnaissance", color: "#ff5a5a" },
  imaging: { name: "Earth imaging", color: "#ffb02e" },
  comms: { name: "Communications", color: "#4fa8ff" },
  nav: { name: "Navigation", color: "#37d39b" },
  weather: { name: "Weather", color: "#7fd6e8" },
  station: { name: "Space station", color: "#ffffff" },
  other: { name: "Science, tech & undisclosed", color: "#b9c2cf" },
  debris: { name: "Debris & rocket bodies", color: "#6b7380" }
};
function purposeKey(i) {
  const f = S.flags[i]; if (f & F_MIL) return f & F_EST ? "milest" : "mil";
  return CAT_TYPE[CATS[S.cat[i]]];
}
function altKm(i) { const n = S.el[i][0] * 2 * Math.PI / 86400; return Math.cbrt(398600.4418 / (n * n)) - RE; }
function starlinkShell(i) {
  if (altKm(i) < 400) return "raising / deorbiting";
  const inc = S.el[i][2]; return inc < 38 ? "33° shell" : inc < 48 ? "43° shell" : inc < 60 ? "53° shell" : inc < 80 ? "70° shell" : "polar shell";
}
function typeText(i) {
  const k = purposeKey(i), base = { milest: "Military (secret, est.)", mil: "Military", imaging: "Imaging", comms: "Comms", nav: "Navigation", weather: "Weather", station: "Space station", other: CATS[S.cat[i]] === "science" ? "Science" : "Other / undisclosed", debris: CATS[S.cat[i]] === "rocket" ? "Rocket body" : "Debris" }[k];
  return S.group[i] === SL ? `${base} · Starlink ${starlinkShell(i)}` : base;
}
// Names of everything in view, grouped by what it does
const ROLL_ORDER = ["milest", "mil", "imaging", "comms", "nav", "weather", "station", "other", "debris"];
let rollT = 0;
function renderRollcall(list) {
  const box = $("rollcall"); if (box.hidden) return;
  const now = performance.now(); if (now - rollT < 1500 && box._h) return; rollT = now;
  const order = Object.fromEntries(ROLL_ORDER.map((k, n) => [k, n]));
  const rows = list.slice().sort((a, b) => (order[purposeKey(a)] - order[purposeKey(b)]) || S.name[a].localeCompare(S.name[b], "en", { numeric: true }));
  const MAX = 700, shown = rows.slice(0, MAX);
  let html = `<table class="rc-table"><thead><tr><th>Satellite</th><th>Country</th><th>Type</th><th>Orbit</th></tr></thead><tbody>` +
    shown.map(i => { const g = GROUPS[S.group[i]], own = S.owners[S.owner[i]], k = purposeKey(i);
      return `<tr data-i="${i}" class="${i === selected ? "sel" : ""}"><td><span class="sw" style="background:${PURPOSE[k].color}"></span>${esc(S.name[i])}</td><td><span class="sw" style="background:${g.color}"></span>${esc(g.id === "OTH" || g.id === "EU" || g.id === "INTL" || g.id === "TBD" ? own[1] : g.id === "SL" ? "USA (Starlink)" : g.name)}</td><td>${esc(typeText(i))}</td><td>${ORBITS[S.orbit[i]]} · ${Math.round(altKm(i)).toLocaleString("en-IN")} km</td></tr>`; }).join("") + `</tbody></table>`;
  if (rows.length > MAX) html += `<div class="sub foot">Showing ${MAX} of ${fmt(rows.length)}. Narrow the filters (country or type) to see the rest.</div>`;
  if (!list.length) html = `<div class="sub">Nothing matching the filters is over this area right now.</div>`;
  if (box._h !== html) { box.innerHTML = html; box._h = html; }
}
$("rollcall").onclick = e => { const b = e.target.closest("[data-i]"); if (b) select(+b.dataset.i, true); };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// ---------------------------------------------------------------- labels
const labelsEl = $("labels");
const pools = { sat: [], city: [], state: [] };
function poolGet(kind, k) {
  const p = pools[kind];
  if (!p[k]) { const d = document.createElement("div"); d.className = "lbl " + kind; labelsEl.appendChild(d); p[k] = d; d._h = ""; }
  return p[k];
}
function poolHide(kind, from) { const p = pools[kind]; for (let k = from; k < p.length; k++) if (p[k].style.display !== "none") p[k].style.display = "none"; }
let labelCands = [];
function pickLabelCandidates() {
  const b = pair[1]; labelCands = [];
  if (!b) return;
  for (let i = 0; i < S.n; i++) {
    if (!visible[i] || !b.ok[i]) continue;
    const f = S.flags[i], c = S.cat[i];
    if (c >= 7 || /^(UNKNOWN|TBA|OBJECT [A-Z]+$)/.test(S.name[i])) continue;
    let pr = 0;
    const over = inArea(b, i);
    const mega = /^(STARLINK|ONEWEB|KUIPER|QIANFAN|GUOWANG|HULIANWANG|GEESAT|FLOCK|LEMUR|GLOBALSTAR|IRIDIUM|ORBCOMM)/.test(S.name[i]);
    if (over) pr = (f & F_MIL) ? 6 : CATS[c] === "imaging" ? 5 : mega ? 2 : 3;
    else pr = (f & F_MIL) ? 1 : 0.5;
    if (pr) labelCands.push(i, pr);
  }
}
const _q = new THREE.Vector3(), _sp = new THREE.Vector3();
function occluded(p) {
  // does the camera->p segment hit the Earth before reaching p?
  const C = camera.position, dx = p.x - C.x, dy = p.y - C.y, dz = p.z - C.z;
  const a = dx * dx + dy * dy + dz * dz, bq = 2 * (C.x * dx + C.y * dy + C.z * dz), c = C.lengthSq() - 1;
  const disc = bq * bq - 4 * a * c; if (disc < 0) return false;
  const t = (-bq - Math.sqrt(disc)) / (2 * a);
  return t > 0 && t < 0.999;
}
function toScreen(p, out) {
  _sp.copy(p).project(camera);
  if (_sp.z > 1 || _sp.x < -1.05 || _sp.x > 1.05 || _sp.y < -1.05 || _sp.y > 1.05) return null;
  out.x = (_sp.x + 1) / 2 * innerWidth; out.y = (1 - _sp.y) / 2 * innerHeight; return out;
}
function updateLabels() {
  const show = $("showLabels").checked, sc = { x: 0, y: 0 };
  const taken = new Set(), cell = (x, y) => ((x / 130) | 0) + "," + ((y / 18) | 0);
  const free = (x, y) => !taken.has(cell(x, y)) && !taken.has(cell(x + 65, y));
  const take = (x, y) => { taken.add(cell(x, y)); taken.add(cell(x + 65, y)); };
  let k = 0;
  const sats = [];
  if (selected >= 0 && posAt(selected, _q) && !occluded(_q) && toScreen(_q, sc)) sats.push([selected, 99, sc.x, sc.y]);
  if (show) {
    for (let j = 0; j < labelCands.length; j += 2) {
      const i = labelCands[j]; if (i === selected || !posAt(i, _q) || occluded(_q) || !toScreen(_q, sc)) continue;
      sats.push([i, labelCands[j + 1] - _q.distanceTo(camera.position) * 0.02, sc.x, sc.y]);
    }
    sats.sort((a, b) => b[1] - a[1]);
  }
  const dist0 = camera.position.length(), labelCap = dist0 > 6 ? 34 : dist0 > 3.5 ? 34 : 60;
  for (const [i, , x, y] of sats) {
    if (k >= labelCap) break;
    const lx = x + 9, ly = y - 9;
    if (i !== selected && !free(lx, ly)) continue;
    const est = S.flags[i] & F_EST;
    take(lx, ly); if (est) take(lx, ly + 16);
    const d = poolGet("sat", k++);
    const h = `<span>${esc(S.name[i])}${est ? `<em>${EST_LABEL}</em>` : ""}</span>`;
    if (d._h !== h) { d.innerHTML = h; d._h = h; }
    const cls = "lbl sat" + (S.group[i] === 0 ? " india" : "") + (est ? " est" : "") + (i === selected ? " sel" : "");
    if (d.className !== cls) d.className = cls;
    d.style.display = ""; d.style.transform = `translate(${lx.toFixed(1)}px, ${ly.toFixed(1)}px) translateY(-50%)`;
  }
  poolHide("sat", k);
  // cities and states, when zoomed toward India
  const dist = camera.position.length(), showGeo = $("showBorders").checked;
  let kc = 0;
  if (showGeo && dist < 6) {
    const maxRank = dist > 3.4 ? 3 : dist > 2.6 ? 10 : dist > 1.9 ? 30 : dist > 1.5 ? 90 : dist > 1.25 ? 400 : dist > 1.12 ? 2000 : 1e9;
    let tried = 0;
    for (const c of cityPts) {
      if (!c.site && c.rank >= maxRank) continue;
      if (++tried > 6000) break;   // keep frames smooth in countries with tens of thousands of towns
      if (occluded(c.v) || !toScreen(c.v, sc)) continue;
      if (!free(sc.x, sc.y)) continue; take(sc.x, sc.y);
      const d = poolGet("city", kc++);
      if (d._h !== c.n) { d.textContent = c.n; d._h = c.n; }
      d.style.display = ""; d.style.transform = `translate(${(sc.x - 4).toFixed(1)}px, ${sc.y.toFixed(1)}px) translateY(-50%)`;
    }
  }
  poolHide("city", kc);
  let ks = 0;
  if (showGeo && dist < 2.4) {
    for (const s of selStateLabels) {
      const v = llToVec(s.lat, s.lon, 1.001, _q);
      if (occluded(v) || !toScreen(v, sc) || !free(sc.x - 30, sc.y)) continue;
      take(sc.x - 30, sc.y);
      const d = poolGet("state", ks++);
      if (d._h !== s.n) { d.textContent = s.n; d._h = s.n; }
      d.style.display = ""; d.style.transform = `translate(${sc.x.toFixed(1)}px, ${sc.y.toFixed(1)}px) translate(-50%, -50%)`;
    }
  }
  poolHide("state", ks);
}

// ---------------------------------------------------------------- selection, orbit path, info
const orbitMat = new LineMaterial({ color: 0xffffff, linewidth: 1.6, transparent: true, opacity: 0.85, depthWrite: false, toneMapped: false });
const trackMat = new LineMaterial({ color: 0xffffff, linewidth: 1.2, transparent: true, opacity: 0.45, depthWrite: false, toneMapped: false, dashed: false });
lineMats.push(orbitMat, trackMat);
lineMats.forEach(m => m.resolution.set(innerWidth, innerHeight));
let orbitLine = null, trackLine = null, orbitRef = { g: 0, t: 0, real: 0 };
const nadir = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
  new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35, depthWrite: false }));
nadir.visible = false; nadir.frustumCulled = false; scene.add(nadir);

function eciAt(i, t) {
  try { const pv = propagate(satrecOf(i), new Date(t)); return pv && pv.position && isFinite(pv.position.x) ? pv : null; } catch (e) { return null; }
}
function buildOrbit(i) {
  for (const l of [orbitLine, trackLine]) if (l) { scene.remove(l); l.geometry.dispose(); }
  orbitLine = trackLine = null;
  if (i < 0) return;
  const P = 1440 / S.el[i][0] * 60000, t0 = sim.t, g0 = gstime(new Date(t0)), cg = Math.cos(g0), sg = Math.sin(g0);
  const pts = [], tr = [], v = new THREE.Vector3(), w = new THREE.Vector3();
  let prev = null;
  for (let k = 0; k <= 360; k++) {
    const pv = eciAt(i, t0 + P * k / 360); if (!pv) { prev = null; continue; }
    const p = pv.position;
    ecfToScene(p.x * cg + p.y * sg, -p.x * sg + p.y * cg, p.z, v);
    if (prev) pts.push(prev.x, prev.y, prev.z, v.x, v.y, v.z);
    prev = v.clone();
  }
  prev = null;
  const span = Math.min(P, 86400000);
  for (let k = 0; k <= 300; k++) {
    const t = t0 - span * 0.25 + span * k / 300, pv = eciAt(i, t); if (!pv) { prev = null; continue; }
    const p = pv.position, g = gstime(new Date(t));
    ecfToScene(p.x * Math.cos(g) + p.y * Math.sin(g), -p.x * Math.sin(g) + p.y * Math.cos(g), p.z, w).setLength(1.003);
    if (prev) tr.push(prev.x, prev.y, prev.z, w.x, w.y, w.z);
    prev = w.clone();
  }
  const col = new THREE.Color(GROUPS[S.group[i]].color);
  if (S.flags[i] & F_EST && filt.mil) col.set(0xff3df2);
  orbitMat.color.copy(col); trackMat.color.copy(col);
  if (pts.length) { const g = new LineSegmentsGeometry(); g.setPositions(pts); orbitLine = new LineSegments2(g, orbitMat); orbitLine.renderOrder = 4; scene.add(orbitLine); }
  if (tr.length) { const g = new LineSegmentsGeometry(); g.setPositions(tr); trackLine = new LineSegments2(g, trackMat); trackLine.renderOrder = 3; scene.add(trackLine); }
  orbitRef = { g: g0, t: t0, real: performance.now() };
}
function select(i, fly = false) {
  selected = i;
  refreshSizes(); buildOrbit(i);
  $("info").hidden = i < 0; nadir.visible = i >= 0; $("india").classList.toggle("compact", i >= 0);
  if (i < 0) return;
  renderInfo(true);
  if (fly && posAt(i, _q)) {
    const d = Math.max(camera.position.length(), _q.length() * 1.9 + 0.6);
    flyTo(_q.clone().setLength(d));
  }
  if (history.replaceState) { const u = new URL(location); u.searchParams.set("select", S.norad[i]); history.replaceState(null, "", u); }
}
let flight = null;
function flyTo(target, ms = 1400) { flight = { from: camera.position.clone(), to: target, t0: performance.now(), ms }; }
// Totals for the owner of the clicked satellite: everything that country (or company) has in orbit.
function ownerStats(test) {
  const st = { total: 0, active: 0, mil: 0, debris: 0, orb: [0, 0, 0, 0], over: 0 }, b = pair[1];
  for (let k = 0; k < S.n; k++) {
    if (!test(k)) continue;
    const c = CATS[S.cat[k]], junk = c === "debris" || c === "rocket";
    st.total++; if (junk) st.debris++; else { if (S.flags[k] & F_ACTIVE) st.active++; if (S.flags[k] & F_MIL) st.mil++; st.orb[S.orbit[k]]++; }
    if (!junk && b && b.ok[k] && inArea(b, k)) st.over++;
  }
  return st;
}
function ownerTotals(i) {
  const own = S.owners[S.owner[i]], code = own[0], isSL = S.group[i] === SL, ownIdx = S.owner[i];
  const label = isSL ? "Starlink (SpaceX)" : own[1];
  const st = isSL ? ownerStats(k => S.group[k] === SL) : ownerStats(k => S.owner[k] === ownIdx);
  const area = AREAS[regionMode] ? AREAS[regionMode].name : "the area";
  const row = (t, v) => `<div><span class="sub">${t}</span><b>${fmt(v)}</b></div>`;
  const filtered = isSL ? (filt.groups.size === 1 && filt.groups.has(SL) && !filt.owner) : filt.owner === code;
  return `<div class="own-card">
    <div class="own-head">${esc(label)}: everything in orbit</div>
    <div class="own-grid">${row("Total objects", st.total)}${row("Working satellites", st.active)}${row("Military", st.mil)}${row("Debris & rocket bodies", st.debris)}</div>
    <div class="sub own-orb">Satellites by orbit: LEO ${fmt(st.orb[0])} · MEO ${fmt(st.orb[1])} · GEO ${fmt(st.orb[2])} · HEO ${fmt(st.orb[3])}</div>
    <div class="sub own-orb">Its satellites over ${esc(area)} right now: <b>${fmt(st.over)}</b></div>
    <button class="own-btn" data-own="${esc(code)}" data-sl="${isSL ? 1 : 0}" data-on="${filtered ? 1 : 0}">${filtered ? "Show all owners again" : `Show only ${esc(label)}'s satellites`}</button>
  </div>`;
}
$("infoBody").addEventListener("click", e => {
  const b = e.target.closest(".own-btn"); if (!b) return;
  if (b.dataset.on === "1") { filt.owner = ""; filt.groups = new Set(GROUPS.map((_, i) => i)); }
  else if (b.dataset.sl === "1") { filt.owner = ""; filt.groups = new Set([SL]); }
  else { filt.owner = b.dataset.own; filt.groups = new Set(GROUPS.map((_, i) => i)); }
  $("ownerSelect").value = filt.owner;
  [...$("ownerQuick").children].forEach(x => x.classList.toggle("on", b.dataset.on === "1" ? x.dataset.g === "all" : b.dataset.sl === "1" && x.dataset.g === "SL"));
  applyFilters(); renderInfo(true);
});
function renderInfo(full) {
  const i = selected; if (i < 0) return;
  const pv = eciAt(i, sim.t);
  let alt = "–", spd = "–", where = "", lat = 0, lon = 0;
  if (pv) {
    const g = gstime(new Date(sim.t)), geo = eciToGeodetic(pv.position, g);
    alt = geo.height; lat = geo.latitude * R2D; lon = geo.longitude * R2D;
    spd = Math.hypot(pv.velocity.x, pv.velocity.y, pv.velocity.z);
    const reg = pair[1] && pair[1].reg[i];
    where = reg === 2 ? "Over India now" : reg === 1 ? "Within 1,500 km of India" : "";
  }
  if (full) {
    const f = S.flags[i], own = S.owners[S.owner[i]], e = S.el[i], c = CATS[S.cat[i]];
    const a = Math.cbrt(398600.4418 / Math.pow(e[0] * 2 * Math.PI / 86400, 2));
    const per = a * (1 - e[1]) - RE, apo = a * (1 + e[1]) - RE;
    const age = (sim.t / 1000 - S.epoch[i]) / 86400;
    const purpose = S.purposes[S.purpose[i]] || (f & F_MIL && c !== "debris" && c !== "rocket" ? `Military – ${CAT_DESC[c].toLowerCase()}` : CAT_DESC[c]);
    const operator = S.operators[S.op[i]] || own[1];
    const tags = [
      S.group[i] === 0 ? `<span class="tag india">India</span>` : "",
      f & F_MIL ? `<span class="tag mil">Military</span>` : "",
      f & F_EST ? `<span class="tag est">${EST_LABEL}</span>` : "",
      `<span class="tag">${ORBIT_DESC[ORBITS[S.orbit[i]]]}</span>`,
      f & F_ACTIVE ? `<span class="tag">Operational</span>` : (c === "debris" || c === "rocket" ? "" : `<span class="tag">Not operational / unknown</span>`)
    ].join("");
    $("infoBody").innerHTML = `
      <h3>${esc(S.name[i])}</h3>
      <div class="sub">NORAD ${S.norad[i]} · ${esc(S.intl[i] || "no international designator")}</div>
      <div>${tags}</div>
      <div class="live-row">
        <div><span class="sub">Altitude</span><b id="iAlt">–</b></div>
        <div><span class="sub">Speed</span><b id="iSpd">–</b></div>
      </div>
      <dl>
        <dt>Country</dt><dd>${esc(GROUPS[S.group[i]].id === "OTH" || GROUPS[S.group[i]].id === "EU" || GROUPS[S.group[i]].id === "INTL" ? own[1] : GROUPS[S.group[i]].name)}</dd>
        <dt>Owner</dt><dd>${esc(operator)}</dd>
        <dt>Purpose</dt><dd>${esc(purpose)}</dd>
        <dt>Launched</dt><dd>${S.launch[i] ? new Date(S.launch[i] + "T00:00:00Z").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }) : "–"}</dd>
        <dt>Ground point</dt><dd id="iGeo">–</dd>
        <dt>Orbit</dt><dd>${Math.round(per).toLocaleString()} × ${Math.round(apo).toLocaleString()} km, ${e[2].toFixed(1)}°</dd>
        <dt>Period</dt><dd>${(1440 / e[0]).toFixed(1)} min</dd>
        <dt>Elements epoch</dt><dd>${new Date(S.epoch[i] * 1000).toISOString().slice(0, 16).replace("T", " ")} UTC (${Math.abs(age) < 1 ? "<1" : Math.round(Math.abs(age))} d ${age >= 0 ? "old" : "ahead"})</dd>
      </dl>
      ${ownerTotals(i)}
      ${f & F_EST ? `<div class="warn">Position is <b>${EST_LABEL}</b>: this object's orbit is not published officially. The elements come from amateur observers (Mike McCants' classified TLE file) and can be off by tens to thousands of kilometres.</div>` : ""}`;
  }
  const ia = $("iAlt"); if (!ia) return;
  ia.textContent = typeof alt === "number" ? `${fmt(Math.round(alt))} km` : alt;
  $("iSpd").textContent = typeof spd === "number" ? `${spd.toFixed(2)} km/s` : spd;
  $("iGeo").textContent = pv ? `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? "N" : "S"} ${Math.abs(lon).toFixed(2)}°${lon >= 0 ? "E" : "W"}${where ? " · " + where : ""}` : "–";
}

// picking
let downAt = null;
canvas.addEventListener("pointerdown", e => { downAt = [e.clientX, e.clientY]; });
canvas.addEventListener("pointerup", e => {
  if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 5) return;
  const sc = { x: 0, y: 0 }; let best = -1, bd = (e.pointerType === "touch" ? 22 : 12) ** 2;
  for (let i = 0; i < S.n; i++) {
    if (!visible[i] || !posAt(i, _q) || !toScreen(_q, sc)) continue;
    const d = (sc.x - e.clientX) ** 2 + (sc.y - e.clientY) ** 2;
    if (d < bd && !occluded(_q)) { bd = d; best = i; }
  }
  select(best);
});
canvas.addEventListener("dblclick", () => { if (selected >= 0) select(selected, true); });
$("infoClose").onclick = () => select(-1);

// ---------------------------------------------------------------- UI
function chip(container, key, label, color, on, count) {
  const b = document.createElement("button"); b.className = "chip" + (on ? "" : " off"); b.dataset.key = key;
  b.innerHTML = (color ? `<span class="sw" style="background:${color}"></span>` : "") + esc(label) + (count != null ? ` <span class="n">${fmt(count)}</span>` : "");
  container.appendChild(b); return b;
}
function renderChips() {
  const cc = $("countryChips"), tc = $("typeChips"), oc = $("orbitChips");
  const gCount = new Array(GROUPS.length).fill(0), tCount = {}, oCount = {};
  for (let i = 0; i < S.n; i++) {
    gCount[S.group[i]]++;
    const t = CAT_TYPE[CATS[S.cat[i]]]; tCount[t] = (tCount[t] || 0) + 1;
    if (S.flags[i] & F_MIL) tCount.military = (tCount.military || 0) + 1;
    oCount[ORBITS[S.orbit[i]]] = (oCount[ORBITS[S.orbit[i]]] || 0) + 1;
  }
  cc.innerHTML = ""; tc.innerHTML = ""; oc.innerHTML = "";
  GROUPS.forEach((g, i) => chip(cc, i, g.name, g.color, !filt.owner && filt.groups.has(i), gCount[i]));
  TYPES.forEach(t => chip(tc, t.id, t.name, t.id === "military" ? "#ff3df2" : null, !filt.mil && filt.types.has(t.id) || filt.mil && t.id === "military", tCount[t.id] || 0));
  ORBITS.forEach(o => chip(oc, o, o, null, filt.orbits.has(o), oCount[o] || 0));
  $("typeChips").style.opacity = filt.mil ? 0.5 : 1;
}
$("countryChips").onclick = e => {
  const b = e.target.closest(".chip"); if (!b) return;
  const k = +b.dataset.key; filt.owner = ""; $("ownerSelect").value = "";
  if (e.shiftKey || e.metaKey || e.ctrlKey) { filt.groups = new Set([k]); } else filt.groups.has(k) ? filt.groups.delete(k) : filt.groups.add(k);
  applyFilters();
};
$("typeChips").onclick = e => {
  const b = e.target.closest(".chip"); if (!b) return;
  if (filt.mil) { $("milMode").checked = false; filt.mil = false; }
  const k = b.dataset.key;
  if (e.shiftKey || e.metaKey || e.ctrlKey) filt.types = new Set([k]); else filt.types.has(k) ? filt.types.delete(k) : filt.types.add(k);
  applyFilters();
};
$("orbitChips").onclick = e => {
  const b = e.target.closest(".chip"); if (!b) return;
  const k = b.dataset.key; filt.orbits.has(k) ? filt.orbits.delete(k) : filt.orbits.add(k); applyFilters();
};
document.querySelectorAll("[data-all],[data-none]").forEach(b => b.onclick = () => {
  const all = b.dataset.all, which = all || b.dataset.none;
  if (which === "country") { filt.owner = ""; $("ownerSelect").value = ""; filt.groups = all ? new Set(GROUPS.map((_, i) => i)) : new Set(); }
  else { filt.mil = false; $("milMode").checked = false; filt.types = all ? new Set(TYPES.map(t => t.id)) : new Set(); }
  applyFilters();
});
$("ownerSelect").onchange = e => { filt.owner = e.target.value; applyFilters(); };
$("milMode").onchange = e => { filt.mil = e.target.checked; applyFilters(); if (selected >= 0) buildOrbit(selected); };
$("activeOnly").onchange = e => { filt.active = e.target.checked; applyFilters(); };
$("showBorders").onchange = e => { overlay.visible = e.target.checked; };
$("showClouds").onchange = e => { clouds.visible = e.target.checked && !!earthU.tCloud.value; earthU.uClouds.value = e.target.checked ? 1 : 0; };
$("regionMode").onclick = e => {
  const b = e.target.closest("button[data-mode]"); if (!b || b.closest("#placeResults") || !AREAS[+b.dataset.mode]) return;
  showPicked(false);
  setArea(+b.dataset.mode, true);
};
document.querySelectorAll(".panel-toggle").forEach(b => b.onclick = () => $(b.dataset.target).classList.toggle("collapsed"));
if (innerWidth < 860) { $("filters").classList.add("collapsed"); $("india").classList.add("collapsed"); }

function setArea(mode, fly) {
  regionMode = mode;
  if (AREAS[mode] && AREAS[mode].poly) computePoly(pair[1]);
  rollT = 0; if ($("rollcall")) $("rollcall")._h = "";
  $("regionMode").querySelectorAll("button[data-mode]").forEach(x => x.classList.toggle("on", +x.dataset.mode === mode));
  if (fly || innerWidth >= 860) $("india").classList.remove("collapsed");
  refreshSizes(); updateCounter(); pickLabelCandidates(); passState.dirty = true; renderPasses();
  $("btnIndia").textContent = "⌖ " + AREAS[mode].short;
  const isCity = !!AREAS[mode].city && !AREAS[mode].poly;
  document.querySelector(".el-row").hidden = !isCity;
  document.querySelector('#tabs [data-tab="passes"]').hidden = !isCity;
  if (!isCity && tab === "passes") document.querySelector('#tabs [data-tab="names"]').click();
  highlightArea(); filterRows();
  if (selected >= 0) renderInfo(true);
  if (fly) flyTo(llToVec(AREAS[mode].ll[0], AREAS[mode].ll[1], AREAS[mode].d));
}
function chinaWatch(mode) {
  filt.owner = ""; $("ownerSelect").value = "";
  filt.groups = new Set([GROUPS.findIndex(g => g.id === "PRC")]);
  filt.types = new Set(TYPES.map(t => t.id).filter(t => t !== "debris"));
  filt.orbits = new Set(ORBITS); filt.mil = false; $("milMode").checked = false;
  applyFilters(); setArea(mode, true);
  document.querySelectorAll("#quickViews button").forEach(b => b.classList.toggle("on", b.dataset.qv === "prc" + mode));
}
$("quickViews").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.qv === "prc3") chinaWatch(3);
  else if (b.dataset.qv === "prc4") chinaWatch(4);
  else {
    filt.owner = ""; $("ownerSelect").value = ""; filt.groups = new Set(GROUPS.map((_, i) => i)); filt.types = new Set(TYPES.map(t => t.id));
    filt.orbits = new Set(ORBITS); filt.mil = false; $("milMode").checked = false; filt.active = false; $("activeOnly").checked = false;
    applyFilters(); setArea(2, false); $("btnIndia").click();
    document.querySelectorAll("#quickViews button").forEach(x => x.classList.remove("on"));
  }
};

// ---------------------------------------------------------------- upcoming passes over Kashmir / North East
// Military and imaging satellites (the ones that can watch the ground) that pass the current filters.
const passState = { list: [], t0: 0, mode: 0, pending: false, dirty: true, id: 0, cands: 0 };
function passCandidates() {
  const idx = [];
  for (let i = 0; i < S.n; i++) {
    if (!visible[i] || S.orbit[i] === 2) continue;                      // geostationary ones never "pass"; they sit in view
    if (CATS[S.cat[i]] === "debris" || CATS[S.cat[i]] === "rocket") continue;
    idx.push(i);
  }
  if (idx.length <= 2500) return idx;
  return idx.filter(i => (S.flags[i] & F_MIL) || CATS[S.cat[i]] === "imaging" || CATS[S.cat[i]] === "station" || S.group[i] === 0);
}
function requestPasses() {
  if (!worker || regionMode < 3) return;
  const idx = passCandidates(); passState.cands = idx.length;
  passState.dirty = false; passState.mode = regionMode; passState.t0 = sim.t;
  if (idx.length > 2600) { passState.list = []; passState.tooMany = true; renderPasses(); return; }
  passState.tooMany = false; passState.pending = true; renderPasses();
  worker.postMessage({ type: "passes", id: ++passState.id, idx, zone: AREAS[regionMode].zone, t: sim.t - 20 * 60000, hours: 6.5 });
}
function onPasses(m) {
  if (m.id !== passState.id) return;
  passState.pending = false; passState.list = m.list.sort((a, b) => a.start - b.start); renderPasses();
}
function rel(ms) {
  const m = Math.round(ms / 60000);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`;
}
function renderPasses() {
  const box = $("passes");
  if (tab !== "passes") { box.hidden = true; return; }
  box.hidden = false;
  if (regionMode < 3) { box.innerHTML = `<div class="sub">Pick one of the watch areas above to list upcoming passes.</div>`; box._h = ""; return; }
  box.hidden = false;
  const where = AREAS[regionMode].name;
  let html = `<div class="pass-head">Next passes over ${where}: military, imaging, space stations and Indian satellites (all types when the filters are narrow)</div>`;
  if (passState.tooMany) html += `<div class="sub">${fmt(passState.cands)} candidates: pick one country (or a China watch view) to list passes.</div>`;
  else if (passState.pending && !passState.list.length) html += `<div class="sub">Working out passes…</div>`;
  else {
    const now = sim.t, rows = passState.list.filter(p => p.end > now).slice(0, 12);
    const parked = sightList.filter(i => S.orbit[i] === 2 && ((S.flags[i] & F_MIL) || CATS[S.cat[i]] === "imaging" || S.orbit[i] === 2));
    if (parked.length) html += `<div class="parked"><div class="sub">Parked in view all the time, 35,786 km up (geostationary): <b>${fmt(parked.length)}</b></div>` +
      parked.sort((a, b) => ((S.flags[b] & F_MIL) - (S.flags[a] & F_MIL)) || S.name[a].localeCompare(S.name[b])).slice(0, 40).map(i => `<button class="pk${S.flags[i] & F_MIL ? " mil" : ""}" data-i="${i}">${esc(S.name[i])}</button>`).join("") + `</div>`;
    if (!rows.length) html += `<div class="sub">No passes in the next few hours with these filters.</div>`;
    for (const p of rows) {
      const i = p.i, live = p.start <= now, f = S.flags[i];
      const when = live ? `<b class="nowtag">overhead now</b> · ${rel(p.end - now)} left` :
        `in ${rel(p.start - now)} · ${new Date(p.start).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" })} IST`;
      const kind = PURPOSE[purposeKey(i)];
      html += `<button class="pass${live ? " live" : ""}" data-i="${i}"><span class="sw" style="background:${kind.color}"></span><span class="pn">${esc(S.name[i])}${f & F_EST ? ` <i>est.</i>` : ""}</span><span class="pe">${Math.round(p.peak)}°</span><span class="pw sub">${when}</span></button>`;
    }
    html += `<div class="sub foot">Peak = highest elevation seen from the area. Times follow the map clock; window ${rows.length ? "covers the next ~6 hours" : ""}.</div>`;
  }
  if (box._h !== html) { box.innerHTML = html; box._h = html; }
}
$("passes").onclick = e => { const b = e.target.closest("button.pass, button.pk"); if (b) select(+b.dataset.i, true); };

function fillOwnerSelect() {
  const sel = $("ownerSelect"), counts = new Map();
  for (let i = 0; i < S.n; i++) counts.set(S.owner[i], (counts.get(S.owner[i]) || 0) + 1);
  sel.length = 1;
  [...counts.entries()].sort((a, b) => S.owners[a[0]][1].localeCompare(S.owners[b[0]][1])).forEach(([o, n]) => {
    const op = document.createElement("option"); op.value = S.owners[o][0]; op.textContent = `${S.owners[o][1]} (${fmt(n)})`; sel.appendChild(op);
  });
}

// search
const sIn = $("search"), sOut = $("searchResults");
let sHits = [], sSel = 0;
sIn.addEventListener("input", () => {
  const q = sIn.value.trim().toUpperCase(); sHits = []; sSel = 0;
  if (q.length >= 2) {
    const num = /^\d+$/.test(q) ? +q : -1;
    for (let i = 0; i < S.n && sHits.length < 40; i++) if (S.norad[i] === num || S.name[i].toUpperCase().includes(q)) sHits.push(i);
    sHits.sort((a, b) => (S.name[a].toUpperCase().startsWith(q) ? 0 : 1) - (S.name[b].toUpperCase().startsWith(q) ? 0 : 1) || (S.cat[a] - S.cat[b]));
    sHits = sHits.slice(0, 12);
  }
  sOut.innerHTML = sHits.map((i, k) => `<button data-i="${i}" class="${k === sSel ? "sel" : ""}"><span>${esc(S.name[i])}</span><span class="sub">${esc(S.owners[S.owner[i]][0])} · ${S.norad[i]}</span></button>`).join("");
  sOut.hidden = !sHits.length;
});
sIn.addEventListener("keydown", e => {
  if (e.key === "Enter" && sHits.length) { chooseHit(sHits[sSel]); }
  else if (e.key === "ArrowDown" || e.key === "ArrowUp") { sSel = (sSel + (e.key === "ArrowDown" ? 1 : -1) + sHits.length) % sHits.length; [...sOut.children].forEach((b, k) => b.classList.toggle("sel", k === sSel)); e.preventDefault(); }
  else if (e.key === "Escape") { sOut.hidden = true; sIn.blur(); }
});
sOut.onclick = e => { const b = e.target.closest("button"); if (b) chooseHit(+b.dataset.i); };
function chooseHit(i) {
  sOut.hidden = true; sIn.value = S.name[i]; sIn.blur();
  if (!visible[i]) { // make sure the chosen object is shown
    filt.owner = ""; filt.groups.add(S.group[i]); filt.orbits.add(ORBITS[S.orbit[i]]); filt.active = false; $("activeOnly").checked = false;
    if (filt.mil && !(S.flags[i] & F_MIL)) { filt.mil = false; $("milMode").checked = false; }
    filt.types.add(CAT_TYPE[CATS[S.cat[i]]]); if (S.flags[i] & F_MIL) filt.types.add("military");
    applyFilters();
  }
  const go = () => posAt(i, _q) ? select(i, true) : setTimeout(go, 100);
  go();
}

// time controls
function setSpeed(v) {
  sim.speed = v; sim.paused = false; if (v !== 1) sim.live = false;
  [...$("speeds").children].forEach(b => b.classList.toggle("on", +b.dataset.speed === v));
  syncTimeUi();
}
function goLive() { sim.live = true; sim.paused = false; sim.speed = 1; sim.t = Date.now(); resync(); setSpeed(1); }
$("speeds").onclick = e => { const b = e.target.closest("button"); if (b) setSpeed(+b.dataset.speed); };
$("btnLive").onclick = goLive;
$("btnPause").onclick = () => { sim.paused = !sim.paused; if (sim.paused) sim.live = false; syncTimeUi(); };
$("ownerQuick").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  filt.owner = ""; $("ownerSelect").value = "";
  filt.groups = b.dataset.g === "all" ? new Set(GROUPS.map((_, i) => i)) : new Set([GROUPS.findIndex(g => g.id === b.dataset.g)]);
  [...$("ownerQuick").children].forEach(x => x.classList.toggle("on", x === b));
  applyFilters();
};
$("btnIndia").onclick = () => flyTo(llToVec(AREAS[regionMode].ll[0], AREAS[regionMode].ll[1], AREAS[regionMode].d));
$("elMode").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  minEl = +b.dataset.el; [...$("elMode").children].forEach(x => x.classList.toggle("on", x === b));
  if (worker) worker.postMessage({ type: "minEl", minEl });
  resync(); passState.dirty = true; passState.list = []; renderPasses();
};
$("tabs").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  tab = b.dataset.tab; [...$("tabs").children].forEach(x => x.classList.toggle("on", x === b));
  $("indiaBars").hidden = tab !== "count"; $("rollcall").hidden = tab !== "names";
  $("rollcall")._h = ""; updateCounter(); renderPasses();
};
function syncTimeUi() {
  $("btnLive").classList.toggle("on", sim.live && !sim.paused);
  $("btnPause").classList.toggle("on", sim.paused);
  $("btnPause").textContent = sim.paused ? "▶" : "❚❚";
}
addEventListener("keydown", e => {
  if (e.target.tagName === "INPUT" || e.target.tagName === "SELECT") return;
  if (e.key === " ") { $("btnPause").click(); e.preventDefault(); }
  else if (e.key === "l" || e.key === "L") goLive();
  else if (e.key === "Escape") select(-1);
});
function clockText() {
  const d = new Date(sim.t);
  const utc = d.toLocaleString("en-GB", { timeZone: "UTC", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const ist = d.toLocaleString("en-GB", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const off = (sim.t - Date.now()) / 60000;
  const rel = sim.live ? "live" : Math.abs(off) < 1 ? "now" : (off > 0 ? "+" : "−") + (Math.abs(off) >= 1440 ? `${(Math.abs(off) / 1440).toFixed(1)} d` : Math.abs(off) >= 60 ? `${Math.floor(Math.abs(off) / 60)} h ${Math.round(Math.abs(off) % 60)} m` : `${Math.round(Math.abs(off))} min`);
  $("clockUtc").textContent = `${utc} UTC`;
  $("clockIst").textContent = `IST ${ist} · ${rel}${sim.paused ? " · paused" : sim.speed !== 1 ? ` · ${sim.speed}×` : ""}`;
}

// ---------------------------------------------------------------- live data refresh (CelesTrak, CORS enabled)
function parseCsv(text) {
  const rows = []; let row = [], f = "", q = false;
  for (let k = 0; k < text.length; k++) {
    const ch = text[k];
    if (q) { if (ch === '"') { if (text[k + 1] === '"') { f += '"'; k++; } else q = false; } else f += ch; }
    else if (ch === '"') q = true;
    else if (ch === ",") { row.push(f); f = ""; }
    else if (ch === "\n" || ch === "\r") { if (ch === "\r" && text[k + 1] === "\n") k++; row.push(f); rows.push(row); row = []; f = ""; }
    else f += ch;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  return rows;
}
async function refreshData() {
  const btn = $("btnRefresh"); btn.disabled = true; btn.textContent = "↻ Fetching…";
  try {
    const res = await fetch("https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=csv", { cache: "no-store" });
    const text = await res.text();
    if (!text.startsWith("OBJECT_NAME")) throw new Error(text.trim().split("\n").slice(0, 2).join(" ") || `HTTP ${res.status}`);
    const rows = parseCsv(text), hdr = rows.shift(), col = Object.fromEntries(hdr.map((h, k) => [h.trim(), k]));
    const byId = new Map(); for (let i = 0; i < S.n; i++) byId.set(S.norad[i], i);
    const objs = S.meta.objects; let upd = 0, add = 0;
    const tbd = S.owners.findIndex(o => o[0] === "TBD");
    for (const r of rows) {
      if (r.length < hdr.length) continue;
      const id = +r[col.NORAD_CAT_ID], ep = Date.parse(r[col.EPOCH] + "Z") / 1000;
      const el = ["MEAN_MOTION", "ECCENTRICITY", "INCLINATION", "RA_OF_ASC_NODE", "ARG_OF_PERICENTER", "MEAN_ANOMALY", "BSTAR", "MEAN_MOTION_DOT", "MEAN_MOTION_DDOT"].map(k => +r[col[k]]);
      const i = byId.get(id);
      if (i != null) { if (ep >= objs[i][7]) { objs[i][7] = ep; objs[i].splice(8, 9, ...el); objs[i][5] |= F_ACTIVE; upd++; } }
      else {
        const name = r[col.OBJECT_NAME], n = el[0], e = el[1], a = Math.cbrt(398600.4418 / Math.pow(n * 2 * Math.PI / 86400, 2)) - RE;
        const orbit = e > 0.25 ? "HEO" : a < 2000 ? "LEO" : (1440 / n > 1400 && 1440 / n < 1480 && e < 0.05) ? "GEO" : "MEO";
        const cat = /^(STARLINK|ONEWEB|KUIPER|QIANFAN|HULIANWANG|GUOWANG|IRIDIUM|GLOBALSTAR|ORBCOMM)/.test(name) ? "comms" : "other";
        let oc = /^STARLINK|^KUIPER/.test(name) ? "US" : /^(QIANFAN|HULIANWANG|GUOWANG|YAOGAN|JILIN|CZ-|SHIYAN|TJS|BEIDOU|FENGYUN|GAOFEN|TIANHUI|TIANLIAN|CHINASAT|ZHONGXING|SHIJIAN|CSS|TIANHE|WENTIAN|MENGTIAN|CHUANGXIN|XINGYUN|TIANQI|GEESAT|CENTISPACE|HAIYANG|ZIYUAN|SUPERVIEW|BEIJING|TIANTONG|LUOJIA|TIANMU|YUNHAI|HUANJING)/.test(name) ? "PRC" : "TBD";
        let oi = S.owners.findIndex(o => o[0] === oc); if (oi < 0) oi = tbd;
        objs.push([id, name, r[col.OBJECT_ID], oi, cat, F_ACTIVE, "", ep, ...el, 0, 0, orbit]); add++;
      }
    }
    const keepSel = selected >= 0 ? S.norad[selected] : -1;
    ingest(S.meta); S.source = "live"; S.fetchedAt = new Date();
    buildPoints(); await startWorker(); applyFilters(); fillOwnerSelect();
    selected = -1; if (keepSel >= 0) { const i = S.norad.indexOf(keepSel); if (i >= 0) setTimeout(() => select(i), 400); }
    dataInfo(); toast(`Updated ${fmt(upd)} orbits and added ${fmt(add)} new objects from CelesTrak.`);
  } catch (err) {
    toast(/not updated|2 hours/i.test(err.message) ? "CelesTrak only allows one download of this data every 2 hours from each address. Still showing the current data."
      : `Couldn't download from CelesTrak (${err.message.slice(0, 100)}). It may be offline, or rate-limiting this address (one download per dataset every 2 hours). Still showing the current data.`, 7000);
  }
  btn.disabled = false; btn.textContent = "↻ Refresh data";
}
$("btnRefresh").onclick = refreshData;
// full screen: works when the page (or the frame it sits in) allows it; otherwise the button hides itself
function toggleFull() {
  const el = document.documentElement;
  if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
  else (el.requestFullscreen || el.webkitRequestFullscreen).call(el).catch?.(() => toast("Full screen isn't allowed here. Use your browser's full-screen key (Ctrl+Cmd+F on Mac, F11 on Windows)."));
}
if (!(document.fullscreenEnabled || document.webkitFullscreenEnabled)) $("btnFull").title = "Use your browser's full-screen key (Ctrl+Cmd+F on Mac, F11 on Windows)";
$("btnFull").onclick = toggleFull;
addEventListener("fullscreenchange", () => { $("btnFull").textContent = document.fullscreenElement ? "⛶ Exit full screen" : "⛶ Full screen"; setTimeout(resize, 100); });
addEventListener("keydown", e => { if ((e.key === "f" || e.key === "F") && !/INPUT|SELECT/.test(e.target.tagName)) toggleFull(); });
let toastT = 0;
function toast(msg, ms = 4000) { const t = $("toast"); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, ms); }
function dataInfo() {
  const when = S.source === "live" ? S.fetchedAt : new Date(S.meta.snapshotEpoch * 1000);
  const age = (Date.now() - when) / 86400000;
  const est = S.flags.reduce((a, f) => a + (f & F_EST ? 1 : 0), 0);
  $("dataInfo").textContent = `${fmt(S.n)} objects · ${S.source === "live" ? "live from CelesTrak" : "snapshot"} ${when.toLocaleString("en-GB", { timeZone: "UTC", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })} UTC` +
    (est ? ` · ${fmt(est)} amateur-tracked` : "") + (age > 7 ? ` · ${Math.round(age)} days old, positions drift: refresh if online` : "");
}

// ---------------------------------------------------------------- 3D satellite models (nearest few hundred only)
// Far away every object is a dot. Close to the camera, the nearest MODEL_MAX objects also get a small 3D model of
// their kind (solar wings, gold foil, dishes, rocket stages, debris), lit by the real sun. Dots stay for the rest.
const MODEL_MAX = 350;
const MC = { gold: "#c9a045", silver: "#c3c8d0", panel: "#1d2f72", panelHi: "#2c46a6", white: "#e9ebee", dark: "#30333a", grey: "#8a8d93" };
function part(geo, color, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  geo = geo.toNonIndexed(); geo.rotateX(rx); geo.rotateY(ry); geo.rotateZ(rz); geo.translate(x, y, z);
  const c = new THREE.Color(color), n = geo.attributes.position.count, col = new Float32Array(n * 3);
  for (let k = 0; k < n; k++) { col[3 * k] = c.r; col[3 * k + 1] = c.g; col[3 * k + 2] = c.b; }
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3)); return geo;
}
function merge(parts) {
  const keys = ["position", "normal", "color"], out = new THREE.BufferGeometry();
  for (const k of keys) {
    const total = parts.reduce((t, g) => t + g.attributes[k].array.length, 0), arr = new Float32Array(total); let o = 0;
    for (const g of parts) { arr.set(g.attributes[k].array, o); o += g.attributes[k].array.length; }
    out.setAttribute(k, new THREE.BufferAttribute(arr, 3));
  }
  return out;
}
const B = (w, h, d) => new THREE.BoxGeometry(w, h, d), C = (r, h, seg = 12) => new THREE.CylinderGeometry(r, r, h, seg);
// local axes: x = direction of travel, y = away from Earth, z = sideways (where the solar wings go)
const wings = (len, w, gap, col = MC.panel) => [part(B(w, 0.02, len), col, 0, 0, gap + len / 2), part(B(w, 0.02, len), col, 0, 0, -gap - len / 2), part(C(0.025, gap * 2, 6), MC.grey, 0, 0, 0, Math.PI / 2)];
const MODELS = {
  starlink: merge([part(B(1.0, 0.1, 0.55), MC.silver), part(B(0.95, 0.015, 2.6), MC.panelHi, 0, 0.12, 1.75, 0.25), part(C(0.02, 0.5, 6), MC.grey, 0, 0.06, 0.45, Math.PI / 2)]),
  geo: merge([part(B(0.7, 0.75, 0.7), MC.gold), ...wings(2.1, 0.55, 0.45), part(C(0.32, 0.05, 20), MC.white, 0.15, -0.45, 0), part(C(0.24, 0.05, 20), MC.white, -0.2, 0.42, 0.1, 0.4)]),
  nav: merge([part(B(0.6, 0.7, 0.55), MC.gold), ...wings(1.4, 0.45, 0.35), part(B(0.5, 0.06, 0.45), MC.white, 0, -0.38, 0)]),
  leocomms: merge([part(B(0.8, 0.35, 0.45), MC.silver), ...wings(1.0, 0.4, 0.3, MC.panelHi)]),
  imaging: merge([part(C(0.3, 1.2, 6), MC.gold, 0, 0, 0, 0, 0, Math.PI / 2), part(C(0.2, 0.08, 16), MC.dark, 0, -0.32, 0.0), ...wings(0.95, 0.4, 0.35)]),
  weather: merge([part(B(0.65, 0.65, 0.85), MC.white), part(B(0.55, 0.02, 1.4), MC.panel, 0, 0.1, 1.15), part(C(0.15, 0.25, 10), MC.dark, 0, -0.45, 0)]),
  station: merge([part(B(0.12, 0.12, 4.2), MC.silver), ...[-1.9, -1.2, 1.2, 1.9].flatMap(z => [part(B(0.7, 0.02, 0.55), MC.panelHi, 0, 0.25, z), part(B(0.7, 0.02, 0.55), MC.panelHi, 0, -0.25, z)]),
    part(C(0.22, 1.8, 12), MC.white, 0, 0, 0, 0, 0, Math.PI / 2), part(C(0.18, 0.9, 12), MC.white, 0.4, 0, 0.45, Math.PI / 2), part(B(0.4, 0.02, 0.9), MC.white, -0.6, 0.4, 0)]),
  rocket: merge([part(C(0.22, 1.7, 14), MC.white, 0, 0, 0, 0, 0, Math.PI / 2), part(new THREE.ConeGeometry(0.2, 0.35, 12), MC.dark, -1.0, 0, 0, 0, 0, Math.PI / 2), part(C(0.225, 0.08, 14), MC.dark, 0.5, 0, 0, 0, 0, Math.PI / 2)]),
  debris: merge([part(new THREE.IcosahedronGeometry(0.22, 0), MC.grey, 0, 0, 0, 0.3, 0.7, 0.2), part(B(0.35, 0.02, 0.2), MC.panel, 0.18, 0.05, 0.1, 0.5, 0.3, 0.2)]),
  other: merge([part(B(0.55, 0.55, 0.55), MC.gold), ...wings(0.7, 0.4, 0.3)])
};
const modelMat = new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 70, specular: 0x666666 });
const models = {};
for (const [k, g] of Object.entries(MODELS)) { g.computeBoundingSphere(); const m = new THREE.InstancedMesh(g, modelMat, MODEL_MAX); m.count = 0; m.frustumCulled = false; m.renderOrder = 4; scene.add(m); models[k] = m; }
const sunLight = new THREE.DirectionalLight(0xffffff, 2.4); scene.add(sunLight);
scene.add(new THREE.AmbientLight(0x8fa0c0, 0.9));
function modelKind(i) {
  const c = CATS[S.cat[i]], o = S.orbit[i];
  if (c === "debris") return "debris"; if (c === "rocket") return "rocket"; if (c === "station") return "station";
  if (S.group[i] === SL) return "starlink";
  if (c === "nav") return "nav"; if (c === "weather") return "weather";
  if (c === "comms") return o === 2 || o === 3 ? "geo" : "leocomms";
  if (c === "imaging" || (S.flags[i] & F_MIL)) return o === 2 ? "geo" : "imaging";
  return "other";
}
let modelSet = [], modelOn = new Uint8Array(0), modelTick = 0;
const _m4 = new THREE.Matrix4(), _fx = new THREE.Vector3(), _up = new THREE.Vector3(), _rt = new THREE.Vector3(), _mp = new THREE.Vector3();
function pickModels() {
  const camD = camera.position.length(), next = [];
  if (pair[0] && $("show3d").checked) {
    const cand = [], lim = Math.max(0.15, 0.35 * (camD - 1));
    for (let i = 0; i < S.n; i++) {
      if (!visible[i] || !posAt(i, _mp)) continue;
      const d = _mp.distanceTo(camera.position); if (d > lim) continue;
      cand.push(d, i);
    }
    const idx = []; for (let k = 0; k < cand.length; k += 2) idx.push(k);
    idx.sort((a, b) => cand[a] - cand[b]);
    for (let k = 0; k < Math.min(idx.length, MODEL_MAX); k++) next.push(cand[idx[k] + 1]);
  }
  if (modelOn.length !== S.n) modelOn = new Uint8Array(S.n);
  modelOn.fill(0); for (const i of next) modelOn[i] = 1;
  modelSet = next; refreshSizes();
}
function updateModels() {
  if (++modelTick % 15 === 0) pickModels();
  sunLight.position.copy(sunDir).multiplyScalar(10);
  const cnt = {}; for (const k in models) cnt[k] = 0;
  const [a] = pair;
  for (const i of modelSet) {
    if (!posAt(i, _mp)) continue;
    const kind = modelKind(i), m = models[kind];
    const k3 = 3 * i; _fx.set(a.vel[k3], a.vel[k3 + 2], -a.vel[k3 + 1]).normalize();
    _up.copy(_mp).normalize(); _rt.crossVectors(_fx, _up).normalize(); _fx.crossVectors(_up, _rt);
    const s = Math.min(Math.max(_mp.distanceTo(camera.position) * 0.010, 0.000002), 0.05) * (kind === "station" ? 1.6 : kind === "debris" ? 0.6 : 1);
    _m4.makeBasis(_fx.multiplyScalar(s), _up.multiplyScalar(s), _rt.multiplyScalar(s)).setPosition(_mp);
    m.setMatrixAt(cnt[kind]++, _m4);
  }
  for (const k in models) { models[k].count = cnt[k]; models[k].instanceMatrix.needsUpdate = true; }
}

// ---------------------------------------------------------------- orbit shells, sight lines and view presets
let sightList = [];
const GEO_R = 42164 / RE;
const geoRing = (() => {
  const pts = []; for (let k = 0; k <= 360; k++) { const a = k / 360 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * GEO_R, 0, Math.sin(a) * GEO_R)); }
  const ring = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineDashedMaterial({ color: 0x7fd6e8, transparent: true, opacity: 0.38, dashSize: 0.1, gapSize: 0.07, depthWrite: false, toneMapped: false }));
  ring.computeLineDistances(); ring.renderOrder = 2; ring.visible = false; return ring;   // Starlink lives in low orbit only
})();
const geoLbl = document.createElement("div"); geoLbl.className = "lbl shell"; geoLbl.textContent = "Geostationary belt · 35,786 km"; labelsEl.appendChild(geoLbl);
const meoLbl = document.createElement("div"); meoLbl.className = "lbl shell"; meoLbl.textContent = "Navigation satellites · ~21,500 km"; labelsEl.appendChild(meoLbl);
const SIGHT_MAX = 2500, sightPos = new Float32Array(SIGHT_MAX * 6), sightCol = new Float32Array(SIGHT_MAX * 8);
const sightGeo = new THREE.BufferGeometry();
sightGeo.setAttribute("position", new THREE.BufferAttribute(sightPos, 3).setUsage(THREE.DynamicDrawUsage));
sightGeo.setAttribute("color", new THREE.BufferAttribute(sightCol, 4).setUsage(THREE.DynamicDrawUsage));
const sightLines = new THREE.LineSegments(sightGeo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, toneMapped: false, blending: THREE.AdditiveBlending }));
sightLines.frustumCulled = false; sightLines.renderOrder = 4; scene.add(sightLines);
const _sc = new THREE.Color(), _sa = new THREE.Vector3(), _anchor = new THREE.Vector3();
const areaLL = () => (AREAS[regionMode] && AREAS[regionMode].ll) || [22, 80];
function updateSight() {
  let n = 0;
  if ($("showSight").checked) {
    for (const i of sightList) {
      if (n >= SIGHT_MAX) break;
      if (!visible[i] || !posAt(i, _sa)) continue;
      const mil = S.flags[i] & F_MIL, img = CATS[S.cat[i]] === "imaging";
      _anchor.copy(_sa).setLength(1.002);   // beam straight down to the ground point
      _sc.set(PURPOSE[purposeKey(i)].color);
      const k = n * 6, c = n * 8, al = 0.42;
      sightPos[k] = _anchor.x; sightPos[k + 1] = _anchor.y; sightPos[k + 2] = _anchor.z;
      sightPos[k + 3] = _sa.x; sightPos[k + 4] = _sa.y; sightPos[k + 5] = _sa.z;
      sightCol.set([_sc.r, _sc.g, _sc.b, al, _sc.r, _sc.g, _sc.b, al * 0.15], c);
      n++;
    }
  }
  sightGeo.setDrawRange(0, n * 2);
  sightGeo.attributes.position.needsUpdate = sightGeo.attributes.color.needsUpdate = true;
}
function shellLabels() { geoLbl.style.display = meoLbl.style.display = "none"; return;
  const far = camera.position.length() > 5 && $("showBorders").checked, sc = { x: 0, y: 0 };
  const az = Math.atan2(camera.position.z, camera.position.x) + 0.45;
  for (const [el, r, y] of [[geoLbl, GEO_R, 0], [meoLbl, 26560 / RE, 0]]) {
    const p = _sa.set(Math.cos(az) * r, y, Math.sin(az) * r);
    const ok = far && (el !== meoLbl || camera.position.length() > 6) && !occluded(p) && toScreen(p, sc);
    el.style.display = ok ? "" : "none";
    if (ok) el.style.transform = `translate(${sc.x.toFixed(1)}px, ${sc.y.toFixed(1)}px) translate(-50%, -140%)`;
  }
}
function viewPreset(v) {
  const a = AREAS[regionMode] || {}, ll = areaLL();
  const d = v === "close" ? (a.d || 2.9) : v === "geo" ? 4.2 : 7.5;
  flyTo(llToVec(v === "close" ? ll[0] : Math.max(ll[0] * 0.45, 8), ll[1], d), 1800);
  [...$("viewMode").children].forEach(b => b.classList.toggle("on", b.dataset.view === v));
}
$("viewMode").onclick = e => { const b = e.target.closest("button"); if (b) viewPreset(b.dataset.view); };
$("showSight").onchange = updateSight;

// ---------------------------------------------------------------- resize and loop
function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  lineMats.forEach(m => m.resolution.set(innerWidth, innerHeight));
}
addEventListener("resize", resize);

let lastReal = performance.now(), infoT = 0, clockT = 0, frames = 0, fpsT = performance.now(), fps = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dtReal = Math.min(now - lastReal, 1000); lastReal = now;
  const before = sim.t;
  if (sim.live && !sim.paused) sim.t = Date.now();
  else if (!sim.paused) sim.t += dtReal * sim.speed;
  if (Math.abs(sim.t - before) > stepSim() * 3) resync();
  if (worker) { pumpWorker(); advance(); }
  updateSun(sim.t);
  sunSprite.position.copy(sunDir).multiplyScalar(1400);
  earthU.uCloudShift.value = ((sim.t / 3.6e6) * 0.0009) % 1;   // slow eastward drift
  satU.uTime.value = now / 1000;
  if (flight) {
    const k = Math.min((now - flight.t0) / flight.ms, 1), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
    const r = THREE.MathUtils.lerp(flight.from.length(), flight.to.length(), e);
    camera.position.copy(flight.from).normalize().lerp(flight.to.clone().normalize(), e).setLength(r);
    if (k >= 1) flight = null;
  }
  controls.rotateSpeed = Math.min(0.15 + 0.18 * (camera.position.length() - 1), 0.9);
  controls.update();
  if (selected >= 0) {
    if (orbitLine) orbitLine.rotation.y = -(gstime(new Date(sim.t)) - orbitRef.g);
    if (now - orbitRef.real > 4000 || Math.abs(sim.t - orbitRef.t) > (1440 / S.el[selected][0]) * 60000 * 0.2) buildOrbit(selected);
    if (posAt(selected, _q)) {
      const a = nadir.geometry.attributes.position; a.setXYZ(0, _q.x, _q.y, _q.z); const s = _q.clone().setLength(1.002); a.setXYZ(1, s.x, s.y, s.z); a.needsUpdate = true;
    }
    if (now - infoT > 150) { renderInfo(false); infoT = now; }
  }
  if (now - clockT > 250) {
    clockText(); clockT = now;
    if (regionMode >= 3 && tab === "passes" && !passState.pending && (passState.dirty || passState.mode !== regionMode || sim.t - passState.t0 > 3 * 3600000 || sim.t < passState.t0 - 60000)) requestPasses();
    else if (regionMode >= 3 && tab === "passes") renderPasses();
  }
  if (pair[0]) { updateLabels(); updateSight(); shellLabels(); updateModels(); }
  updateDetail(now);
  renderer.render(scene, camera);
  frames++; if (now - fpsT > 1000) { fps = frames * 1000 / (now - fpsT); frames = 0; fpsT = now; }
}

// ---------------------------------------------------------------- boot
async function getJson(url, tries = 4) {
  for (let k = 1; ; k++) {
    try { const r = await fetch(url); if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`); return await r.json(); }
    catch (e) { if (k >= tries) throw e; await new Promise(r => setTimeout(r, 700 * k)); }
  }
}
async function boot() {
  const setLoad = (p, msg) => { $("loadFill").style.width = (p * 100).toFixed(0) + "%"; if (msg) $("loadText").textContent = msg; };
  setLoad(0.05, "Loading Earth textures…");
  const phone = matchMedia("(pointer: coarse)").matches && Math.min(innerWidth, innerHeight) < 900;
  const big = renderer.capabilities.maxTextureSize >= 8192 && params.get("tex") !== "4k" && !phone;   // phones keep the 4k maps (memory)
  const texP = Promise.all([
    loadTexSoft("../shared/textures/earth_day_4k.jpg"), loadTexSoft("../shared/textures/earth_night_4k.jpg"), loadTexSoft("../shared/textures/earth_topo_water_4k.png", false)
  ]);
  const dataP = Promise.all([getJson("data/catalog.json"), getJson("data/geo.json"), getJson("data/world.json"), getJson("data/cities.json")]);
  const [day, night, topo] = await texP;
  earthU.tDay.value = day; earthU.tNight.value = night; earthU.tTopo.value = topo;
  setLoad(0.35, "Loading satellite catalogue…");
  requestAnimationFrame(frame);
  loadTex("../shared/textures/earth_clouds_4k.jpg", false).then(t => { earthU.tCloud.value = t; clouds.visible = $("showClouds").checked; });
  const [cat, geo, world, cities] = await dataP; S.cities = cities;
  S.geo = geo; buildGeo(geo);
  S.grid = decodeGrid(world.grid); buildAreas(world);
  S.cityNorm = S.cities.map(c => norm(c[0]));
  setLoad(0.6, `Computing ${fmt(cat.objects.length)} orbits…`);
  ingest(cat); buildPoints();
  if (params.get("mil") === "1") { filt.mil = true; $("milMode").checked = true; }
  const rq = params.get("region");
  if (rq === "1") setArea(1, false);
  const want = Object.entries(AREAS).find(([, a]) => a.short.toLowerCase().replace(/\W/g, "") === (rq || "").toLowerCase());
  setArea(want ? +want[0] : 3, false);
  applyFilters(); fillOwnerSelect(); dataInfo(); syncTimeUi();
  [...$("speeds").children].forEach(b => b.classList.toggle("on", +b.dataset.speed === sim.speed));
  await startWorker();
  setLoad(0.9, "Placing satellites…");
  const t0 = performance.now();
  while (!pair[0] && performance.now() - t0 < 15000) await new Promise(r => setTimeout(r, 50));
  setLoad(1, "Ready");
  $("loading").classList.add("done");
  const sel = +params.get("select");
  if (sel) { const i = S.norad.indexOf(sel); if (i >= 0) select(i, params.get("fly") === "1"); }
  if (big) {   // swap in the 8k day and night maps once the page is interactive
    Promise.all([loadTex("../shared/textures/earth_day_8k.jpg"), loadTex("../shared/textures/earth_night_8k.jpg")]).then(([d, n]) => {
      earthU.tDay.value = d; earthU.tNight.value = n; day.dispose(); night.dispose();
    }).catch(() => {});
  }
  // all 135,000 towns and cities (GeoNames, population 1,000+) arrive in the background
  getJson("data/places.json").then(pl => { S.places = pl; S.placeNorm = pl.map(p => norm(p[0])); }).catch(() => {});
  getJson("data/cities-all.json").then(all => { S.cities = all; S.cityNorm = all.map(c => norm(c[0])); highlightArea(); placeSearch(); dataInfo(); }).catch(() => {});
  window.__satmap = { ownerStats, inArea, get pair() { return pair; }, get AREAS() { return AREAS; }, get regionMode() { return regionMode; }, passState, setArea, chinaWatch, S, filt, sim, scene, overlay, renderer, get fps() { return fps; }, get workerMs() { return workerMs; }, get selected() { return selected; }, select, visible, posAt, camera, controls, refreshData, applyFilters };
}
boot().catch(err => { console.error(err); $("loadText").innerHTML = "Couldn't start (" + esc(String(err && err.message || err)) + "). <a href='javascript:location.reload()' style='color:#9fc3ff'>Reload</a>"; });
